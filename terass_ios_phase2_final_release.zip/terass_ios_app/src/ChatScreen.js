import React, { useState, useCallback, useEffect } from 'react';
import { GiftedChat } from 'react-native-gifted-chat';

// OpenAI API インターフェースとシナリオ定義のインポート
import { fetchOpenAIResponse } from './openai';
import { depositProcedureScenario } from './scenarios';
import { queryDocs, fetchLatestDocs } from './rag';
import { KNOWLEDGE_API_URL } from './config';
import { searchVectorDocs } from './vectorSearch';

/**
 * チャット画面コンポーネント。
 * 初回表示時にウェルカムメッセージを表示し、
 * ユーザーの入力を受け取ってチャット履歴に追加します。
 * TODO: OpenAI API への問い合わせを実装し、アシスタントの回答を追加する。
 */
export default function ChatScreen() {
  const [messages, setMessages] = useState([]);
  // シナリオの現在ステップを示すインデックス。null の場合はシナリオ未開始。
  const [scenarioIndex, setScenarioIndex] = useState(null);

  useEffect(() => {
    // 初期メッセージの設定
    setMessages([
      {
        _id: 1,
        text: 'TERASS AIへようこそ。ご質問をどうぞ。',
        createdAt: new Date(),
        user: {
          _id: 2,
          name: 'Terass Assistant',
          avatar: require('../assets/terass_avatar.png'),
        },
      },
    ]);

    // RAG用の最新ナレッジが設定されていれば取得
    (async () => {
      if (KNOWLEDGE_API_URL) {
        await fetchLatestDocs(KNOWLEDGE_API_URL);
      }
    })();
  }, []);

  /**
   * メッセージ送信時の処理。
   * 現在はユーザーからのメッセージを履歴に追加するのみで、
   * アシスタントからの応答は追加しません。
   * @param {Array} msgs 送信されたメッセージ
   */
  const onSend = useCallback(
    (msgs = []) => {
      // ユーザーのメッセージテキスト
      const userMsg = msgs[0]?.text || '';
      // まずはユーザーのメッセージを履歴に追加
      setMessages(previousMessages => GiftedChat.append(previousMessages, msgs));

      // シナリオ進行中の場合は次のステップを送信
      if (scenarioIndex !== null) {
        const nextIndex = scenarioIndex + 1;
        if (nextIndex < depositProcedureScenario.length) {
          const nextStep = depositProcedureScenario[nextIndex];
          setScenarioIndex(nextIndex);
          setMessages(prev =>
            GiftedChat.append(prev, [
              {
                _id: Math.random().toString(),
                text: nextStep.text,
                createdAt: new Date(),
                user: {
                  _id: 2,
                  name: 'Terass Assistant',
                  avatar: require('../assets/terass_avatar.png'),
                },
              },
            ]),
          );
        } else {
          // 最終ステップを終えたらシナリオを終了
          setScenarioIndex(null);
        }
        return;
      }

      // Phase2: handle special keywords for loan diagnosis and Picks search
      if (userMsg.includes('ローン診断')) {
        // iOS版ではGUIフォームがないため簡易案内を表示
        setMessages(prev =>
          GiftedChat.append(prev, [
            {
              _id: Math.random().toString(),
              text: 'ローン診断はデスクトップ版でご利用いただけます。デスクトップアプリでローン診断ボタンを押してお試しください。',
              createdAt: new Date(),
              user: {
                _id: 2,
                name: 'Terass Assistant',
                avatar: require('../assets/terass_avatar.png'),
              },
            },
          ]),
        );
        return;
      }
      if (userMsg.includes('Picks検索')) {
        setMessages(prev =>
          GiftedChat.append(prev, [
            {
              _id: Math.random().toString(),
              text: 'Picks検索はデスクトップ版で準備中です。最新情報が利用可能になり次第お知らせします。',
              createdAt: new Date(),
              user: {
                _id: 2,
                name: 'Terass Assistant',
                avatar: require('../assets/terass_avatar.png'),
              },
            },
          ]),
        );
        return;
      }
      // キーワードが含まれていればシナリオを開始
      if (userMsg.includes('手付金') || userMsg.toLowerCase().includes('scenario')) {
        const firstStep = depositProcedureScenario[0];
        setScenarioIndex(0);
        setMessages(prev =>
          GiftedChat.append(prev, [
            {
              _id: Math.random().toString(),
              text: `手付金預かりシナリオを開始します。\n${firstStep.text}`,
              createdAt: new Date(),
              user: {
                _id: 2,
                name: 'Terass Assistant',
                avatar: require('../assets/terass_avatar.png'),
              },
            },
          ]),
        );
        return;
      }

      // 通常の質問は OpenAI へ問い合わせて応答を追加
      (async () => {
        const reply = await fetchOpenAIResponse(userMsg, []);
        // AI からの返答を追加
        setMessages(prev =>
          GiftedChat.append(prev, [
            {
              _id: Math.random().toString(),
              text: reply,
              createdAt: new Date(),
              user: {
                _id: 2,
                name: 'Terass Assistant',
                avatar: require('../assets/terass_avatar.png'),
              },
            },
          ]),
        );
        // キーワードに基づいて簡易資料検索を実行
        const docResults = queryDocs(userMsg);
        if (docResults.length > 0) {
          // 結果をテキストでまとめる
          const snippetText = docResults
            .map(r => `[${r.name}]\n${r.snippet.trim()}`)
            .join('\n\n');
          setMessages(prev =>
            GiftedChat.append(prev, [
              {
                _id: Math.random().toString(),
                text: snippetText,
                createdAt: new Date(),
                user: {
                  _id: 2,
                  name: '資料検索',
                  avatar: require('../assets/terass_avatar.png'),
                },
              },
            ]),
          );
        }

        // ベクタDB検索APIが設定されている場合はリモート検索も実行します
        const vectorResults = await searchVectorDocs(userMsg);
        if (vectorResults && vectorResults.length > 0) {
          const vecText = vectorResults
            .map(r => {
              const snip = r.snippet ? r.snippet.trim() : '';
              return `[${r.name}]\n${snip}`;
            })
            .join('\n\n');
          setMessages(prev =>
            GiftedChat.append(prev, [
              {
                _id: Math.random().toString(),
                text: vecText,
                createdAt: new Date(),
                user: {
                  _id: 2,
                  name: 'ベクタ検索',
                  avatar: require('../assets/terass_avatar.png'),
                },
              },
            ]),
          );
        }
      })();
    },
    [scenarioIndex],
  );

  return (
    <GiftedChat
      messages={messages}
      onSend={messages => onSend(messages)}
      user={{ _id: 1 }}
    />
  );
}