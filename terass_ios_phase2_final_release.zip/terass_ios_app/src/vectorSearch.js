// src/vectorSearch.js
//
// ベクタDB検索のためのモジュールです。
// デスクトップ版のように外部のベクタデータベースにアクセスする代わりに、
// サーバー側に用意された検索APIを呼び出して関連ドキュメントを取得します。

import { VECTOR_API_URL } from './config';

/**
 * クエリに基づいてベクタDB検索APIを呼び出します。
 * サーバーは JSON 形式で { results: [ { name: string, snippet: string }, ... ] } を返すことを想定しています。
 * 接続できない場合や結果がない場合は空配列を返します。
 * @param {string} query 検索語
 * @returns {Promise<Array<{name: string, snippet: string}>>} 検索結果
 */
export async function searchVectorDocs(query) {
  if (!VECTOR_API_URL) {
    // 設定されていない場合は検索せず空配列を返す
    return [];
  }
  try {
    const res = await fetch(VECTOR_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query }),
    });
    if (!res || !res.ok) {
      console.warn('ベクタ検索APIに接続できませんでした', res && res.status);
      return [];
    }
    const data = await res.json();
    if (data && Array.isArray(data.results)) {
      return data.results;
    }
    return [];
  } catch (err) {
    console.warn('ベクタ検索中にエラーが発生しました', err);
    return [];
  }
}