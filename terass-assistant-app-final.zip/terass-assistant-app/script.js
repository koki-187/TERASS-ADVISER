/*
 * TERASS Assistant main script
 * Provides interactive progress bar and a simple bar chart drawn using
 * the Canvas API. The bar chart updates dynamically based on the
 * progress slider value to demonstrate interactivity.
 */

// DOM elements
const progressRange = document.getElementById('progressRange');
const progressBar = document.getElementById('progressBar');
const progressLabel = document.getElementById('progressLabel');
const canvas = document.getElementById('salesChart');
const ctx = canvas.getContext('2d');

// Sample monthly sales data (in arbitrary units). These arrays are mutable
// and new entries can be added via the UI. The initial values provide
// starting data for the chart.
const initialValues = [5, 10, 7, 8, 12, 9];
const initialLabels = ['4月', '5月', '6月', '7月', '8月', '9月'];

// Data arrays used for drawing; start with initial copies
let dataValues = [...initialValues];
let dataLabels = [...initialLabels];

/**
 * Update the progress bar width and label.
 * @param {number} val - The progress percentage (0-100).
 */
function updateProgress(val) {
  progressBar.style.width = `${val}%`;
  progressLabel.textContent = `${val}%`;
}

/**
 * Draw the chart on the canvas. Supports both bar and line charts.
 * The data values are scaled according to the progress slider to
 * demonstrate dynamic visualization. Chart type is selected via
 * a dropdown in the UI.
 */
function drawChart() {
  const progress = parseInt(progressRange.value, 10);
  // Scaling factor: value between 0.3 and 1.3 based on progress
  const scale = 0.3 + (progress / 100) * 1.0;
  const scaledData = dataValues.map((v) => v * scale);
  const labels = dataLabels;

  const width = canvas.width;
  const height = canvas.height;
  const padding = 40;
  const chartWidth = width - padding * 2;
  const chartHeight = height - padding * 2;
  const barGap = 10;
  const barWidth = scaledData.length > 0
    ? (chartWidth - barGap * (scaledData.length - 1)) / scaledData.length
    : 0;
  const maxVal = Math.max(...scaledData, 1) * 1.1; // avoid zero max

  // Clear previous drawing
  ctx.clearRect(0, 0, width, height);

  // Draw axes
  ctx.strokeStyle = '#6b7280';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padding, padding);
  ctx.lineTo(padding, height - padding);
  ctx.lineTo(width - padding, height - padding);
  ctx.stroke();

  // Determine chart type
  const chartTypeEl = document.getElementById('chartType');
  const chartType = chartTypeEl ? chartTypeEl.value : 'bar';

  ctx.font = '14px Arial';
  ctx.textAlign = 'center';

  if (chartType === 'bar') {
    // Draw bars
    scaledData.forEach((value, i) => {
      const x = padding + i * (barWidth + barGap);
      const barHeight = (value / maxVal) * chartHeight;
      const y = height - padding - barHeight;
      ctx.fillStyle = '#3b82f6';
      ctx.fillRect(x, y, barWidth, barHeight);
      // Value label
      ctx.fillStyle = '#1e3a8a';
      ctx.textBaseline = 'bottom';
      ctx.fillText(value.toFixed(1), x + barWidth / 2, y - 5);
      // Month label
      ctx.fillStyle = '#374151';
      ctx.textBaseline = 'top';
      ctx.fillText(labels[i], x + barWidth / 2, height - padding + 5);
    });
  } else if (chartType === 'line') {
    // Draw line chart
    // Compute points
    const points = scaledData.map((value, i) => {
      const x = padding + i * (chartWidth / (scaledData.length - 1));
      const y = height - padding - (value / maxVal) * chartHeight;
      return { x, y, value };
    });
    // Draw line
    ctx.strokeStyle = '#3b82f6';
    ctx.lineWidth = 2;
    ctx.beginPath();
    points.forEach((pt, i) => {
      if (i === 0) {
        ctx.moveTo(pt.x, pt.y);
      } else {
        ctx.lineTo(pt.x, pt.y);
      }
    });
    ctx.stroke();
    // Draw points and labels
    points.forEach((pt, i) => {
      // Circle for each point
      ctx.fillStyle = '#3b82f6';
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
      ctx.fill();
      // Value label
      ctx.fillStyle = '#1e3a8a';
      ctx.textBaseline = 'bottom';
      ctx.fillText(pt.value.toFixed(1), pt.x, pt.y - 8);
      // Month label
      ctx.fillStyle = '#374151';
      ctx.textBaseline = 'top';
      ctx.fillText(labels[i], pt.x, height - padding + 5);
    });
  }
}

// Event listeners
progressRange.addEventListener('input', () => {
  const val = parseInt(progressRange.value, 10);
  updateProgress(val);
  drawChart();
});

// Chart type change event
const chartTypeEl = document.getElementById('chartType');
if (chartTypeEl) {
  chartTypeEl.addEventListener('change', () => {
    drawChart();
  });
}

// Data entry event: add new data point
const addButton = document.getElementById('addDataButton');
const monthInput = document.getElementById('monthInput');
const valueInput = document.getElementById('valueInput');
if (addButton && monthInput && valueInput) {
  addButton.addEventListener('click', () => {
    const month = monthInput.value.trim();
    const valueStr = valueInput.value.trim();
    const value = parseFloat(valueStr);
    if (month && !isNaN(value)) {
      dataLabels.push(month);
      dataValues.push(value);
      monthInput.value = '';
      valueInput.value = '';
      drawChart();
    }
  });
}

// Initialize on page load
window.addEventListener('DOMContentLoaded', () => {
  // Set initial progress bar state
  updateProgress(progressRange.value);
  // Draw initial chart
  drawChart();

  // Populate metrics summary with static values retrieved from internal connectors.
  // These values represent counts of various entities in HubSpot, GitHub, and Google Drive.
  // In a real implementation, you could fetch these numbers from a backend API.
  const metrics = {
    contacts: 4,        // Number of contacts in HubSpot
    companies: 3,       // Number of companies in HubSpot
    deals: 0,           // Number of deals in HubSpot
    tickets: 0,         // Number of tickets in HubSpot
    openPRs: 2,         // Open pull requests in GitHub
    openIssues: 0,      // Open issues in GitHub
    recentDocs: 5       // Recently modified documents in Google Drive
  };

  // Function to update metrics section
  function updateMetrics() {
    const metricsMap = {
      contactsCount: metrics.contacts,
      companiesCount: metrics.companies,
      dealsCount: metrics.deals,
      ticketsCount: metrics.tickets,
      openPRs: metrics.openPRs,
      openIssues: metrics.openIssues,
      recentDocs: metrics.recentDocs
    };
    Object.entries(metricsMap).forEach(([id, value]) => {
      const el = document.getElementById(id);
      if (el) el.textContent = value;
    });
  }

  // Populate metrics on load
  updateMetrics();

  /*============================
   * Reward Calculation Logic
   * Implements the commission rules:
   * - Self discovery: 75% (or 90% if bonus stage)
   * - HQ leads: 40%
   * - Terass Offer: 55%
   * Bonus stage is triggered when year-to-date total >= 20,000,000 yen.
   */
  function isBonusStage(yearToDateTotal) {
    return yearToDateTotal >= 20000000;
  }

  function calcRewardForDeal(fee, source, yearToDateBefore) {
    let rate = 0;
    let bonus = false;
    if (source === 'self') {
      if (isBonusStage(yearToDateBefore)) {
        rate = 0.90;
        bonus = true;
      } else {
        rate = 0.75;
        bonus = false;
      }
    } else if (source === 'hq') {
      rate = 0.40;
      bonus = false;
    } else if (source === 'terass_offer') {
      rate = 0.55;
      bonus = false;
    } else {
      rate = 0;
    }
    const rewardAmount = Math.round(fee * rate * 100) / 100;
    return {
      rewardAmount,
      rate,
      bonus,
    };
  }

  // Event listener for reward calculation
  const rewardButton = document.getElementById('calcRewardButton');
  if (rewardButton) {
    rewardButton.addEventListener('click', () => {
      const feeEl = document.getElementById('dealFee');
      const sourceEl = document.getElementById('dealSource');
      const ytdEl = document.getElementById('ytdBefore');
      const fee = parseFloat(feeEl.value);
      const source = sourceEl.value;
      const ytd = parseFloat(ytdEl.value) || 0;
      if (isNaN(fee) || fee <= 0) {
        alert('税抜仲介手数料を入力してください');
        return;
      }
      const result = calcRewardForDeal(fee, source, ytd);
      document.getElementById('rewardAmount').textContent = result.rewardAmount.toLocaleString();
      document.getElementById('rewardRate').textContent = (result.rate * 100).toFixed(0) + '%';
      document.getElementById('bonusActivated').textContent = result.bonus ? 'はい' : 'いいえ';
    });
  }

  /*============================
   * Agent Class Determination Logic
   * Uses rules similar to the Python implementation:
   * - Premier: capital >= 30,000,000 & 10 cases (annual); local >= 25,000,000 & 10 cases
   * - Senior: capital >= 12,000,000 & 5 cases (half); local >= 10,000,000 & 5 cases
   * - Expert: capital >= 8,000,000 & 5 cases (half); local >= 6,000,000 & 5 cases
   * - Lead: capital >= 5,000,000 & 5 cases (half); local >= 4,000,000 & 5 cases
   * Default: Unranked, with needed sales/cases for Lead (local) shown.
   */
  const CLASS_RULES = [
    { class: 'Premier', region: 'capital', minSales: 30000000, minCases: 10 },
    { class: 'Premier', region: 'local', minSales: 25000000, minCases: 10 },
    { class: 'Senior', region: 'capital', minSales: 12000000, minCases: 5 },
    { class: 'Senior', region: 'local', minSales: 10000000, minCases: 5 },
    { class: 'Expert', region: 'capital', minSales: 8000000, minCases: 5 },
    { class: 'Expert', region: 'local', minSales: 6000000, minCases: 5 },
    { class: 'Lead', region: 'capital', minSales: 5000000, minCases: 5 },
    { class: 'Lead', region: 'local', minSales: 4000000, minCases: 5 },
  ];

  function determineClass(region, periodSales, cumulativeCases) {
    // Check for classes in order
    for (const rule of CLASS_RULES) {
      if (region === rule.region && periodSales >= rule.minSales && cumulativeCases >= rule.minCases) {
        return { class: rule.class, metSales: true, metCases: true };
      }
    }
    // Default case: compute needed values for Lead (local) as reference
    const leadLocal = CLASS_RULES[CLASS_RULES.length - 1];
    const neededSales = Math.max(0, leadLocal.minSales - periodSales);
    const neededCases = Math.max(0, leadLocal.minCases - cumulativeCases);
    return { class: 'Unranked', neededSales, neededCases };
  }

  // Event listener for class determination
  const classButton = document.getElementById('calcClassButton');
  if (classButton) {
    classButton.addEventListener('click', () => {
      const region = document.getElementById('region').value;
      const periodSalesStr = document.getElementById('periodSales').value;
      const cumulativeCasesStr = document.getElementById('cumulativeCases').value;
      const periodSales = parseFloat(periodSalesStr) || 0;
      const cumulativeCases = parseInt(cumulativeCasesStr, 10) || 0;
      const result = determineClass(region, periodSales, cumulativeCases);
      document.getElementById('classResult').textContent = result.class;
      const detailsEl = document.getElementById('classDetails');
      if (result.class === 'Unranked') {
        detailsEl.textContent = `次のクラス達成まで：売上あと ${result.neededSales.toLocaleString()} 円、成約あと ${result.neededCases} 件`;
      } else {
        detailsEl.textContent = '';
      }
    });
  }

  /*============================
   * Chat advisor logic
   * Implements a simple Q&A chatbot with local history and optional voice input.
   */
  // DOM references for chat
  const chatHistoryEl = document.getElementById('chatHistory');
  const chatInputEl = document.getElementById('chatInput');
  const sendChatBtn = document.getElementById('sendChatBtn');
  const startVoiceBtn = document.getElementById('startVoiceBtn');
  const showHistoryBtn = document.getElementById('showHistoryBtn');
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');

  // Key for storing chat history in localStorage
  const chatStorageKey = 'terassChatHistory';

  // In-memory chat history; array of { role, content }
  let chatHistory = [];
  // Load history from localStorage
  try {
    const storedHistory = localStorage.getItem(chatStorageKey);
    if (storedHistory) {
      chatHistory = JSON.parse(storedHistory);
    }
  } catch (err) {
    console.error('Failed to load chat history:', err);
  }

  /**
   * Save chat history to localStorage.
   */
  function saveChatHistory() {
    try {
      localStorage.setItem(chatStorageKey, JSON.stringify(chatHistory));
    } catch (err) {
      console.error('Failed to save chat history:', err);
    }
  }

  /**
   * Render chat history in the chatHistoryEl container.
   */
  function renderChatHistory() {
    if (!chatHistoryEl) return;
    chatHistoryEl.innerHTML = '';
    chatHistory.forEach((msg) => {
      const wrapper = document.createElement('div');
      wrapper.className = 'chat-message ' + msg.role;
      const bubble = document.createElement('div');
      bubble.className = 'message-bubble ' + msg.role;
      bubble.textContent = msg.content;
      wrapper.appendChild(bubble);
      chatHistoryEl.appendChild(wrapper);
    });
    chatHistoryEl.scrollTop = chatHistoryEl.scrollHeight;
  }

  /**
   * Generate a response for the given user input.
   * Uses simple keyword matching to return canned answers.
   * @param {string} input - User's question
   * @returns {string} - Response from the advisor
   */
  function generateResponse(input) {
    const lower = input.toLowerCase();
    if (lower.includes('手付金')) {
      return '手付金預かりの手順は次のとおりです:\n1. 手付金専用口座に入金されていることを確認します。\n2. 管理者が入金記録を作成し、預り証を発行します。\n3. TERASS Cloudに案件を登録し、進捗を管理します。';
    }
    if (lower.includes('重要事項')) {
      return '重要事項説明書では物件概要、権利関係、法令上の制限、設備状況など52項目を説明します。具体的には所在地、地目、用途地域、建ぺい率・容積率、道路幅員、インフラ設備などを網羅的に確認する必要があります。';
    }
    if (lower.includes('役所調査')) {
      return '役所調査では、用途地域や建築制限、都市計画道路の有無、上下水道やガスの整備状況、災害ハザードマップ等を確認します。調査結果は重要事項説明の根拠となります。';
    }
    if (lower.includes('terass') && lower.includes('picks')) {
      return 'TERASS Picksでは物件情報を一括検索できます。エリア・価格帯など条件を指定し、物件の詳細を確認したり、マイソクの作成が可能です。検索結果から興味のある物件をお気に入り登録し、顧客と共有することもできます。';
    }
    if (lower.includes('報酬') || lower.includes('歩合')) {
      return '仲介手数料からエージェントへの報酬率は自己発見案件で75%、本部紹介案件で40%、Terass Offer案件で55%です。年間売上2,000万円を超えると以降の自己発見案件は90%が適用されます。';
    }
    return '申し訳ありませんが、その質問にはまだ対応していません。別の表現でお尋ねください。';
  }

  /**
   * Handle user message: add to history, generate response, save and render.
   * @param {string} text - User input
   */
  function handleUserMessage(text) {
    const trimmed = text.trim();
    if (!trimmed) return;
    chatHistory.push({ role: 'user', content: trimmed });
    const reply = generateResponse(trimmed);
    chatHistory.push({ role: 'assistant', content: reply });
    saveChatHistory();
    renderChatHistory();
  }

  // Initial render of chat history
  renderChatHistory();

  // Send message on button click
  if (sendChatBtn && chatInputEl) {
    sendChatBtn.addEventListener('click', () => {
      handleUserMessage(chatInputEl.value);
      chatInputEl.value = '';
    });
  }
  // Send message on Enter key
  if (chatInputEl) {
    chatInputEl.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter') {
        ev.preventDefault();
        handleUserMessage(chatInputEl.value);
        chatInputEl.value = '';
      }
    });
  }

  // Clear history
  if (clearHistoryBtn) {
    clearHistoryBtn.addEventListener('click', () => {
      chatHistory = [];
      saveChatHistory();
      renderChatHistory();
    });
  }

  // Show/hide history
  if (showHistoryBtn) {
    showHistoryBtn.addEventListener('click', () => {
      if (!chatHistoryEl) return;
      if (chatHistoryEl.style.display === 'none' || chatHistoryEl.style.display === '') {
        chatHistoryEl.style.display = 'block';
      } else {
        chatHistoryEl.style.display = 'none';
      }
    });
  }

  // Voice input handling using Web Speech API
  if (startVoiceBtn) {
    startVoiceBtn.addEventListener('click', () => {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SpeechRecognition) {
        alert('音声入力はこのブラウザではサポートされていません。');
        return;
      }
      const recognition = new SpeechRecognition();
      recognition.lang = 'ja-JP';
      recognition.interimResults = false;
      startVoiceBtn.disabled = true;
      startVoiceBtn.textContent = '🎤 聞き取り中...';
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        handleUserMessage(transcript);
      };
      recognition.onend = () => {
        startVoiceBtn.disabled = false;
        startVoiceBtn.textContent = '🎤 音声入力';
      };
      recognition.onerror = () => {
        startVoiceBtn.disabled = false;
        startVoiceBtn.textContent = '🎤 音声入力';
      };
      recognition.start();
    });
  }
});