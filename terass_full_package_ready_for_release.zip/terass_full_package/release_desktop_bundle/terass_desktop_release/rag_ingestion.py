"""
rag_ingestion.py
================

This script provides a skeleton for building a Retrieval‑Augmented Generation
(RAG) data pipeline.  It demonstrates how to load textual documents from
various sources, split them into chunks, generate embeddings using the
OpenAI API, and persist those embeddings to a vector store.  The vector
store can then be queried at runtime to provide context for GPT‑based
conversational agents such as the TERASS 業務サポートAI.

The implementation here is intentionally minimal and designed to be
customised.  To adapt it for production use, you should integrate
authentication flows for Notion and Google Drive APIs, handle rate limits
gracefully, and choose an appropriate vector database (e.g. pgvector,
Pinecone, or Chroma).

Usage:

    python rag_ingestion.py --source-folder ./data --output-file embeddings.json

The example above reads all text files under ``data`` and writes a JSON
mapping of chunk texts to embedding vectors into ``embeddings.json``.

Environment Variables:
    OPENAI_API_KEY: your OpenAI API key used to generate embeddings.

Dependencies:
    - openai
    - tiktoken (optional, for token counting/chunking)
    - tqdm (optional, for progress bars)

Note: This script does not directly interact with the api_tool.  Instead it
expects that you have already exported documents from Notion or Google Drive
to local files.  For fetching remote content, consider using the
connector APIs within your application to download relevant documents and
persist them into a staging directory.
"""

import argparse
import json
import os
from pathlib import Path
from typing import Iterable, List, Dict, Any

try:
    import openai  # type: ignore
except ImportError:
    openai = None  # Placeholder for type checkers

try:
    import tiktoken  # type: ignore
except ImportError:
    tiktoken = None

try:
    from tqdm import tqdm  # type: ignore
except ImportError:
    def tqdm(x: Iterable) -> Iterable:
        return x


def read_text_files(folder: Path) -> Dict[str, str]:
    """Recursively read all .txt/.md files from the given folder.

    Args:
        folder: Path to a directory containing text documents.

    Returns:
        A dictionary mapping file paths to their contents.
    """
    texts: Dict[str, str] = {}
    for file_path in folder.rglob("*"):
        if file_path.suffix.lower() in {".txt", ".md"}:
            try:
                texts[str(file_path)] = file_path.read_text(encoding="utf-8")
            except Exception:
                pass
    return texts


def chunk_text(text: str, max_tokens: int = 500) -> List[str]:
    """Split a long string into chunks of approximately `max_tokens` tokens.

    If the tiktoken package is available, the splitter uses the GPT‑4
    encoding to determine token boundaries.  Otherwise it falls back to a
    naïve character split.

    Args:
        text: The input string to be chunked.
        max_tokens: The approximate maximum number of tokens per chunk.

    Returns:
        A list of text chunks.
    """
    if tiktoken is None:
        # Simple fallback: split into roughly equal parts by character length
        approx_chars = max_tokens * 4  # assume ~4 chars per token
        return [text[i : i + approx_chars] for i in range(0, len(text), approx_chars)]

    # Use tiktoken encoding to split by tokens
    enc = tiktoken.encoding_for_model("gpt-4")
    tokens = enc.encode(text)
    chunks = []
    for i in range(0, len(tokens), max_tokens):
        chunk_tokens = tokens[i : i + max_tokens]
        chunks.append(enc.decode(chunk_tokens))
    return chunks


def embed_texts(texts: List[str], model: str = "text-embedding-3-small") -> List[List[float]]:
    """Generate embeddings for a list of texts using the OpenAI API.

    Args:
        texts: The list of text strings to embed.
        model: The embedding model identifier.

    Returns:
        A list of embedding vectors (lists of floats).
    """
    if openai is None:
        raise RuntimeError("openai package not installed.  Install openai to use embeddings.")
    # Set API key from environment
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY not set in environment.")
    openai.api_key = api_key

    # Call embeddings API in batches
    embeddings: List[List[float]] = []
    batch_size = 50  # tune based on token limits and performance
    for i in tqdm(range(0, len(texts), batch_size)):
        batch = texts[i : i + batch_size]
        response = openai.Embedding.create(input=batch, model=model)  # type: ignore
        for item in response["data"]:
            embeddings.append(item["embedding"])  # type: ignore
    return embeddings


def main() -> None:
    parser = argparse.ArgumentParser(description="Ingest documents and build embeddings for RAG.")
    parser.add_argument("--source-folder", type=str, required=True, help="Path to directory of text documents.")
    parser.add_argument(
        "--output-file", type=str, required=True, help="File path to write the embeddings JSON.")
    args = parser.parse_args()

    folder = Path(args.source_folder)
    docs = read_text_files(folder)
    all_chunks: List[str] = []
    metadata: List[Dict[str, Any]] = []
    for path, text in docs.items():
        chunks = chunk_text(text)
        all_chunks.extend(chunks)
        metadata.extend([{"source": path, "chunk_index": idx} for idx in range(len(chunks))])

    embeddings = embed_texts(all_chunks)
    # Persist embeddings alongside their source metadata
    with open(args.output_file, "w", encoding="utf-8") as f:
        json.dump({"embeddings": embeddings, "metadata": metadata, "chunks": all_chunks}, f, ensure_ascii=False)
    print(f"Wrote {len(embeddings)} embeddings to {args.output_file}")


if __name__ == "__main__":
    main()