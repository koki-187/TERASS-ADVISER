# アプリ配布・パッケージングガイド

この資料では、TERASS業務サポートAI を Windows や macOS 向けに配布する際の手順を説明します。Python アプリケーションを単独の実行ファイルにまとめることで、Python や依存ライブラリをインストールしていない環境でも動作するようになります。

## 🧰 利用するツール

ここでは代表的なパッケージングツールとして **PyInstaller** を紹介します。これ以外にも `cx_Freeze` や `briefcase` などがありますが、PyInstaller はシンプルで広く使われています。

### PyInstaller のインストール

1. Python と pip がインストールされていることを確認します。
2. ターミナルで次のコマンドを実行して PyInstaller をインストールします。

   ```bash
   pip install pyinstaller
   ```

   インストールには数分かかる場合があります。

## 📦 パッケージング手順

1. **プロジェクトルートに移動**：

   ```bash
   cd path/to/project
   ```

2. **依存関係の整理**：`requirements.txt` を用意し、必要なパッケージを記載します。例えば：

   ```text
   openai
   python-dotenv
   scikit-learn
   tkinter
   ```

3. **PyInstaller 実行**：次のコマンドで実行可能ファイルを作成します。

   ```bash
   pyinstaller --onefile --name TerassAssistant terass_assistant_with_scenarios.py
   ```

   - `--onefile` は単一の実行ファイルにまとめるオプションです。
   - `--name` で生成されるファイル名を指定します。
   - GUI アプリの場合は `--windowed` を追加するとコンソールが表示されません。

4. **出力ファイルの確認**：
   PyInstaller が完了すると `dist` フォルダに `TerassAssistant`（Windows なら `.exe` 拡張子付き）が生成されます。これを配布ファイルとして利用します。

5. **ライセンスや README の添付**：
   配布物には `LICENSE` や `README` を同梱し、使用方法や注意事項を明記しましょう。

## 💻 Windows への配布

作成した `.exe` ファイルを ZIP にまとめ、社内共有ドライブやメールで配布します。実行時にはウイルス検出ソフトが警告を出す場合があるため、信頼できるファイルであることを通知しておくと良いでしょう。

## 🍎 macOS への配布

macOS では `.app` バンドル形式での配布が一般的です。PyInstaller はデフォルトで `.app` を生成します。生成されたアプリは Gatekeeper によってブロックされることがあるため、開発者が notarization（公証）を行うとより安全に配布できます。

## 📚 追加資料

パッケージングの詳細やトラブルシューティングは、PyInstaller の公式ドキュメント <https://pyinstaller.org/> を参照してください。また、当プロジェクトの `terass-automation-kit.zip` や `terass_complete_package.zip` にはサンプルビルドスクリプトやテンプレートが含まれている場合があるので、必要に応じて参照してください。