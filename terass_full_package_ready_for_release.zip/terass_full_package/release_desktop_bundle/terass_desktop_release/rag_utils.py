"""
rag_utils.py
===============

This module provides simple utilities for building a lightweight
Retrieval‑Augmented Generation (RAG) pipeline without relying on
proprietary embedding services.  Instead of using OpenAI embeddings,
it leverages scikit‑learn's ``TfidfVectorizer`` to transform
documents into high‑dimensional sparse vectors.  While TF‑IDF lacks
the semantic richness of large language models, it is sufficient for
keyword‑based retrieval of internal knowledge base documents.

Functions
---------
``load_documents(folder: str) -> Tuple[List[str], List[dict]]``
    Recursively load ``.md`` and ``.txt`` files from a folder and
    return their contents alongside metadata (path, index).

``build_vectorizer(texts: List[str]) -> Tuple[TfidfVectorizer, csr_matrix]``
    Fit a ``TfidfVectorizer`` on the provided texts and return the
    fitted vectorizer and its document‑term matrix.

``query_documents(query: str, vectorizer, matrix, texts, metadata, top_k=3)``
    Given a user query, compute its TF‑IDF representation and return
    the indices of the ``top_k`` most similar documents based on cosine
    similarity.  Also return the corresponding text snippets and
    metadata.

Usage Example
-------------
>>> texts, meta = load_documents("./phase2_docs")
>>> vectorizer, matrix = build_vectorizer(texts)
>>> results = query_documents("ローン金利", vectorizer, matrix, texts, meta, top_k=2)
for doc, meta in results:
    print(meta['source'], doc[:100])

Limitations
-----------
TF‑IDF retrieval works best when the user's query contains keywords
that also appear in the documents.  For more nuanced semantic
matching, consider replacing this with a dense embedding model when
internet access and additional dependencies are available.
"""

from __future__ import annotations

import os
from typing import List, Tuple, Dict, Any

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel


def load_documents(folder: str) -> Tuple[List[str], List[Dict[str, Any]]]:
    """Load all text/markdown files from ``folder`` recursively.

    Parameters
    ----------
    folder: str
        Path to a directory containing ``.md`` or ``.txt`` files.

    Returns
    -------
    texts: List[str]
        The raw contents of each document.
    metadata: List[Dict[str, Any]]
        A list of metadata dictionaries for each document.  Each
        metadata entry contains at least the ``source`` (absolute file
        path) and ``doc_index`` (its index in the returned list).
    """
    texts: List[str] = []
    metadata: List[Dict[str, Any]] = []
    folder = os.path.abspath(folder)
    for root, _, files in os.walk(folder):
        for filename in files:
            if filename.lower().endswith(('.md', '.txt')):
                path = os.path.join(root, filename)
                try:
                    with open(path, 'r', encoding='utf-8') as f:
                        text = f.read()
                    texts.append(text)
                    metadata.append({"source": path, "doc_index": len(texts) - 1})
                except Exception:
                    continue
    return texts, metadata


def build_vectorizer(texts: List[str]) -> Tuple[TfidfVectorizer, Any]:
    """Fit a TF‑IDF vectorizer on a list of texts.

    Returns the fitted ``TfidfVectorizer`` and its document‑term matrix.
    """
    # Use a simple whitespace and punctuation tokenizer.  Ngram range
    # can be tuned to capture short phrases; here we default to unigrams
    # and bigrams to improve recall.
    vectorizer = TfidfVectorizer(
        max_features=None,
        stop_words='english',
        ngram_range=(1, 2)
    )
    matrix = vectorizer.fit_transform(texts)
    return vectorizer, matrix


def query_documents(
    query: str,
    vectorizer: TfidfVectorizer,
    matrix,
    texts: List[str],
    metadata: List[Dict[str, Any]],
    top_k: int = 3,
) -> List[Tuple[str, Dict[str, Any]]]:
    """Retrieve the top ``k`` documents most relevant to ``query``.

    Parameters
    ----------
    query: str
        The user's query string.
    vectorizer: TfidfVectorizer
        A fitted vectorizer.
    matrix: csr_matrix
        The document‑term matrix produced by the vectorizer.
    texts: List[str]
        The list of original documents.
    metadata: List[Dict[str, Any]]
        Metadata for each document.
    top_k: int, default=3
        How many top results to return.

    Returns
    -------
    results: List[Tuple[str, Dict[str, Any]]]
        A list of tuples where each element is (text, metadata) for the
        retrieved document.
    """
    # Transform the query into the TF‑IDF space
    query_vec = vectorizer.transform([query])
    # Compute cosine similarity between query and all documents
    cosine_similarities = linear_kernel(query_vec, matrix).flatten()
    # Get indices of top_k scores
    top_indices = cosine_similarities.argsort()[::-1][:top_k]
    results: List[Tuple[str, Dict[str, Any]]] = []
    for idx in top_indices:
        # Use copy of metadata to avoid mutation
        doc_meta = metadata[idx].copy()
        results.append((texts[idx], doc_meta))
    return results


__all__ = [
    "load_documents",
    "build_vectorizer",
    "query_documents",
]