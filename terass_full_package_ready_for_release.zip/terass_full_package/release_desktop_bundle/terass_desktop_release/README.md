# TERASS 業務サポートAI – 正式リリース版

このパッケージは、TERASS の不動産エージェント業務をサポートする対話型AIアプリの正式リリース版です。チャットUIから問い合わせるだけで、契約手続きや物件検索、ローン診断などの質問に答えるほか、ガイド付きシナリオやナレッジ検索などの機能が利用できます。

## 📦 同梱物一覧

```
terass_assistant_with_scenarios.py … チャットアプリ本体（Tkinter UI、シナリオ／RAG統合）
scenario_module.py               … 手付金預かりシナリオなどの定義モジュール
rag_utils.py                     … TF‑IDF ベースの簡易RAGユーティリティ
rag_ingestion.py                 … ドキュメントをベクトル化するスクリプト
phase2_docs/                     … 内部ドキュメント（Loan Checker、Picks統合仕様等）
bitwarden_guide.md               … Bitwarden Secrets Manager 利用ガイド
packaging_guide.md               … アプリ配布・パッケージングガイド
README.md                        … このファイル
terass-automation-kit/           … 自動同期・スクレイピング用のテンプレート（Node.js / CI 用）
assets/                          … 参考用スクリーンショット（Notion ページの例など）
env_vars_example.txt             … 環境変数名のサンプル（`.env.example` の内容を値なしで収録）
automation_package_README_JA.md  … 完成パッケージ同梱物の説明（日本語）
```

## 🚀 主な機能

- **チャットUI** – Tkinter を用いた日本語対応のチャット画面。自動スクロール、送信ボタン、クイック質問ボタンを備えています。
- **ナレッジベース** – `phase2_docs` と組み込みナレッジに基づき、簡単な質問には即時回答できます。
- **RAG（Retrieval‑Augmented Generation）** – `rag_utils.py` による TF‑IDF 検索で関連文書をコンテキストとしてモデルに渡し、回答の根拠を向上させます。
- **シナリオ誘導** – `scenario_module.py` に定義された手付金預かり14ステップを順番に提示する機能があります。今後シナリオを追加することも可能です。
- **ヘルプ機能** – 「🔑 Bitwarden利用方法」「🆘 ヘルプを見る」ボタンから、Secrets 管理やパッケージング方法をアプリ内で閲覧できます。

## ⚙️ 動作方法（初心者向け）

1. `python -m pip install -r requirements.txt` で依存ライブラリをインストールします（Python 3.9 以上を推奨）。
2. 必要なシークレット（OPENAI_API_KEY など）を Bitwarden に登録します。Bitwarden とは、パスワードやAPIキーを安全に管理するサービスのことです。詳しい登録方法は `bitwarden_guide.md` にあります。

   ### ⚙️ Mac をお使いの方

   - リポジトリには **`setup_env_mac.sh`** という初期設定用スクリプトが含まれています。このファイルを **`setup_env_mac.command`** に名前を変えることで、ダブルクリックだけで実行できるようになります（拡張子 `.command` のファイルはFinderから直接実行可能です）。
   - 名前を変更したら、一度だけ実行するためにファイルをダブルクリックしてください。これによりBitwardenに保存されているAPIキーなどが `~/.terass/terass.env` という隠しファイルに書き出され、今後はコマンド入力なしでアプリが起動します。
   - ターミナル（Macの「コマンドを入力するアプリ」）を使わない場合でも、この方法で環境設定が完了します。

   ### 🪟 Windows をお使いの方

   - Windows 環境には **`setup_env_windows.ps1`** というPowerShellスクリプトが同梱されています。PowerShellはWindows標準のコマンド操作ツールです。
   - このファイルを右クリックし、「**PowerShell で実行**」を選択してください。初回実行時は、「実行ポリシー」を変更する案内が表示されることがありますが、管理者の指示に従ってください。
   - スクリプト実行後、一度ログアウトまたはPCを再起動すると、Bitwardenのシークレットが自動的に読み込まれるようになります。

   ※ 上記のスクリプトは初回のみ実行すればOKです。以降は毎回 `bws run` のようなコマンドを入力する必要はありません。
3. `python terass_assistant_with_scenarios.py` を実行すると GUI が起動します。Mac/Windows どちらの場合も、上記のスクリプトで環境変数が設定された状態であれば、追加のコマンド入力は不要です。
4. パッケージングや配布方法については `packaging_guide.md` を参照してください。

## 🤖 自動化用スクリプトの活用

このパッケージには、ウェブサイトから情報を収集したり、定期的にデータを同期したりするためのテンプレートとして **`terass-automation-kit/`** が含まれています。これは Node.js と Puppeteer を使ったスクレイピングの雛形で、Bitwarden Secrets Manager からシークレットを受け取り、GitHub Actions や Cron で自動実行できます。

### 使い方の概要

1. `terass-automation-kit/.env.example` を参考に、必要な環境変数名を確認してください。値は Bitwarden などに保存し、コードやリポジトリに書かないようにします。
2. GitHub Actions で定期実行したい場合は、`workflows/ci-deploy.yml` を参考にリポジトリの Actions 設定を行います。必要なトークン（`BW_SM_ACCESS_TOKEN` など）は Secrets に登録してください。
3. 自前サーバで Cron 実行する場合は、`scripts/cron.sh` をサーバ環境に合わせて編集し、`crontab` に登録します。Bitwarden CLI (`bws`) がインストールされている必要があります。
4. スクレイピング対象のサイトや通知方法は `src/scraper.js`、`src/notify.js` をカスタマイズすることで変更できます。詳細は `terass-automation-kit/README.md` および `automation_package_README_JA.md` を参照してください。

## 📁 参考スクリーンショット

`assets/` ディレクトリには、Notion の社内ページ例などのスクリーンショットが含まれています。これらは利用例や UI デザインの参考としてご覧ください。

## 📞 サポート

不明点やバグ報告がありましたら、開発チームまでご連絡ください。