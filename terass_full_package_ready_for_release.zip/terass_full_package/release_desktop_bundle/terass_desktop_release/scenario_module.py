"""
scenario_module.py
===================

This module defines a simple framework for guided conversation scenarios used
by the TERASS 業務サポートAI.  Scenarios are represented as a list of
ordered steps.  Each step includes a prompt to display to the user and an
optional slot name indicating the information the assistant should capture
from the user's response.  In a more sophisticated implementation these
structures could be persisted to and loaded from a database or authored via
No‑Code tools.  For now the scenarios are defined statically in Python.

Usage:

>>> from scenario_module import get_scenario
>>> steps = get_scenario("deposit_procedure")
>>> for step in steps:
...     print(step["prompt"])

This will print the sequence of prompts for the hand‑money deposit procedure.

Note: While the initial implementation simply returns the list of steps,
future versions might include branching logic, validation of user input, and
integration with external systems such as CRM or scheduling services.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Any


@dataclass
class ScenarioStep:
    """Represents a single step in a guided conversation scenario."""
    id: str
    prompt: str
    slot: Optional[str] = None
    # In future versions these fields could be extended with validation
    # requirements, branching conditions, etc.


# Define scenarios here.  Keys are scenario identifiers and values are
# ordered lists of ScenarioStep instances describing the flow.  The
# deposit_procedure scenario corresponds to the 14‑step hand‑money
# procedure defined in the TERASS knowledge base.
SCENARIOS: Dict[str, List[ScenarioStep]] = {
    "deposit_procedure": [
        ScenarioStep(
            id="step1",
            prompt="本人確認は完了しましたか？完了していない場合はご説明します。",
            slot="identity_confirmed",
        ),
        ScenarioStep(
            id="step2",
            prompt="契約書を作成し、内容をご説明しましたか？",
            slot="contract_prepared",
        ),
        ScenarioStep(
            id="step3",
            prompt="重要事項説明を実施し、顧客から同意を得ましたか？",
            slot="disclosure_performed",
        ),
        ScenarioStep(
            id="step4",
            prompt="手付金の額と支払い方法を確認しましたか？",
            slot="deposit_amount_confirmed",
        ),
        ScenarioStep(
            id="step5",
            prompt="預り証の準備はできていますか？",
            slot="receipt_prepared",
        ),
        ScenarioStep(
            id="step6",
            prompt="手付金を受領しましたか？受領時の注意点をご案内します。",
            slot="deposit_received",
        ),
        ScenarioStep(
            id="step7",
            prompt="預り証を発行し、顧客にお渡ししましたか？",
            slot="receipt_issued",
        ),
        ScenarioStep(
            id="step8",
            prompt="TERASS Cloudへ手付金登録を行いましたか？",
            slot="cloud_registered",
        ),
        ScenarioStep(
            id="step9",
            prompt="手付金保全措置の確認・案内を行いましたか？",
            slot="deposit_protection_confirmed",
        ),
        ScenarioStep(
            id="step10",
            prompt="本部へ手付金受領の報告を実施しましたか？",
            slot="headquarters_reported",
        ),
        ScenarioStep(
            id="step11",
            prompt="受領記録や関連書類を保管しましたか？",
            slot="records_stored",
        ),
        ScenarioStep(
            id="step12",
            prompt="決済日を管理し、スケジュールに登録しましたか？",
            slot="closing_scheduled",
        ),
        ScenarioStep(
            id="step13",
            prompt="手付金の充当方法を確認しましたか？",
            slot="allocation_confirmed",
        ),
        ScenarioStep(
            id="step14",
            prompt="上記すべての手続きが完了したことを報告しましたか？",
            slot="final_report_made",
        ),
    ],
    # Additional scenarios can be defined here as needed.
}


def get_scenario(name: str) -> List[ScenarioStep]:
    """Retrieve the list of steps for the given scenario name.

    Args:
        name: The unique identifier of the scenario.

    Returns:
        A list of ScenarioStep instances.  If the scenario is not defined,
        an empty list is returned.
    """
    return SCENARIOS.get(name, [])