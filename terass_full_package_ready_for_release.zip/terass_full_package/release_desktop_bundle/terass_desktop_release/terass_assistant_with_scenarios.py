import os
import tkinter as tk
from tkinter import scrolledtext, messagebox
from openai import OpenAI  # type: ignore
from dotenv import load_dotenv
import datetime
import json
from typing import List, Dict, Any  # for type annotations

# Optional: use PIL for avatar image handling.  We guard the
# import in a try/except so that the application still works even
# if Pillow is not installed.  ImageTk is used to convert PIL
# images into Tkinter compatible PhotoImages.
try:
    from PIL import Image, ImageTk  # type: ignore[attr-defined]
except Exception:
    Image = None  # type: ignore
    ImageTk = None  # type: ignore

# Import simple RAG utilities for local document retrieval.  These
# utilities use a TF‑IDF vectorizer to build a search index over the
# documents in ``phase2_docs``.  If the module or documents are
# unavailable, retrieval will silently degrade and the assistant will
# operate without additional context.
try:
    from rag_utils import load_documents, build_vectorizer, query_documents  # type: ignore
except Exception:
    load_documents = None  # type: ignore
    build_vectorizer = None  # type: ignore
    query_documents = None  # type: ignore

"""
terass_assistant_with_scenarios.py
----------------------------------

This module extends the original TERASS 業務サポートAI implementation by
adding support for guided conversation scenarios defined in
``scenario_module.py``.  In addition to the existing quick question
buttons, a new button triggers the "手付金預かり" scenario, which walks
through the 14‑step deposit procedure.

Note: This file is intended to be a drop‑in replacement for
``terass_assistant.py``.  To use it, rename the file accordingly or
modify your startup scripts to execute this module instead.
"""

# Load environment variables
load_dotenv()

# Initialize OpenAI client
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# Import scenario definitions if available
try:
    from scenario_module import get_scenario  # type: ignore
except Exception:
    def get_scenario(name: str):
        """Fallback when scenario_module is not present.  Returns empty list."""
        return []


# TERASS業務マニュアル
TERASS_KNOWLEDGE = """
【【TERASS業動サポートAI - ナレッジベース】

## 手付金預かり手順（14ステップ）
1.　本人確認　2.　契約書作成　3.　重説実施　4.　手付金確認　5.　預り証準備
6.　手付金受領　7.　預り証発行　8.　TERASS Cloud登録　9.　保全措置確認
10.　本部報告　11.　記録保管　12.　決済日管理　13.　手付金充当　14.　完了報告

## TERASS Picks
物件数284,096件。学区やハザードマップ情報を表示し、物件検索や比較に利用できます。2025年には共有アカウント機能や学区・ハザード情報表示、販売図面アップロードなどが追加されました。

## TERASS特別金利ローン
物件価格の90％まで借入可能で、変動金利0.55〜1.465％（2025年十月時点）。申請期限は2026年3月末までに仮実値結果登録、6月末までに借入実行。融資額は2,000万円〜6億円（ペアローンは最大12億円）、返済期間1〜50年。がん・三大病症・仏ヅどの囲の図頻オプションを選択可能。融資実行後のアンケート回答でキャンペーン報酬3万円（2026年3月末まで）あり。

## TERASS Insight（提案支援プラットフォーム）
页客の価値観をヒアリングし、AI評価によりライフスタイルに合った住まいを提案。評価結果を共有し、面談依頼や物件検索リンクの発行もサポートする新サービス。

## Loan Checker
107金融模閨に応じ、最低金利はSBI新生銀血の0.520％。年収や借入額、希望金利タイプを入力すると、最適なローン商品を提案します。

## Agent Class報酬
エージェントクラスはBeginner〜Chairmanまであり、基本報酬率は75〜90％。自己発見客は75％、ボーナスステージでは90％など取得経路や売上に従って変動します。

## 役所調査6大カテゴリー
都市計画・建築基準法・道路・上下水道・埻藏文化財・その他に分類され、それぞれの手続きや確認事項をまとめています。

## その他注意点
TERASS CloudとTERASS Picksは同一のメールアドレス・パスワードでログインできます。環境変数に適切なキー名（英数字＋アンダースコア）で設定し、Bitwardenから安全に読み込みます。
"""


class ModernTERASSAssistant:
    def __init__(self, root):
        self.root = root
        self.root.title("TERASS業務サポートAI - Premium Edition")
        self.root.geometry("1000x750")
        self.root.configure(bg='#f0f2f5')

        # アイコン設定（Windows用）
        try:
            self.root.iconbitmap('terass_icon.ico')
        except Exception:
            pass

        # Load custom avatar image for the assistant, if available.  We
        # attempt to open ``terass_avatar.png`` in the same
        # directory as this script and convert it to a PhotoImage.  If
        # Pillow is unavailable or the file cannot be opened, we fall
        # back to using an emoji icon later in ``add_message_bubble``.
        self.avatar_photo: Any | None = None  # type: ignore[assignment]
        if Image and ImageTk:
            try:
                base_dir = os.path.dirname(__file__)
                avatar_path = os.path.join(base_dir, 'terass_avatar.png')
                if os.path.exists(avatar_path):
                    img = Image.open(avatar_path)
                    # Resize to a reasonable size for chat bubbles
                    img = img.resize((40, 60), Image.LANCZOS)
                    self.avatar_photo = ImageTk.PhotoImage(img)
            except Exception:
                self.avatar_photo = None

        self.conversation_history: List[Dict[str, str]] = []
        self.message_widgets: List[tk.Frame] = []

        self.system_prompt = f"""TERASS不動産エージェント専用AIアシスタント（GPT-4o-mini版）

{TERASS_KNOWLEDGE}

具体的で実践的なアドバイスを、親しみやすく提供します。
"""

        self.setup_modern_ui()
        self.load_history()

        # Setup local retrieval (RAG) if rag_utils and docs are available.
        # This will index any Markdown/Text files under the ``phase2_docs``
        # directory relative to this script's location.  The index is used
        # to supply related document excerpts to the model when answering
        # user queries.
        self._rag_ready = False
        self._rag_texts = []
        self._rag_meta = []
        self._rag_vectorizer = None
        self._rag_matrix = None
        if load_documents and build_vectorizer and query_documents:
            docs_dir = os.path.join(os.path.dirname(__file__), 'phase2_docs')
            if os.path.exists(docs_dir):
                try:
                    texts, meta = load_documents(docs_dir)
                    # Only build the vectorizer if documents exist
                    if texts:
                        vectorizer, matrix = build_vectorizer(texts)
                        self._rag_ready = True
                        self._rag_texts = texts
                        self._rag_meta = meta
                        self._rag_vectorizer = vectorizer
                        self._rag_matrix = matrix
                except Exception:
                    # If any error occurs during loading, leave RAG disabled
                    self._rag_ready = False

    def setup_modern_ui(self):
        # ヘッダー（グラデーション風）
        header_frame = tk.Frame(self.root, bg='#2563eb', height=80)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)

        # タイトル
        title_label = tk.Label(
            header_frame,
            text="🏠 TERASS業務サポートAI",
            font=("Yu Gothic UI", 20, "bold"),
            bg='#2563eb',
            fg='white'
        )
        title_label.pack(pady=15)

        # サブタイトル
        subtitle_label = tk.Label(
            header_frame,
            text="powered by GPT-4o-mini  |  あなたの業務を24時間サポート",
            font=("Yu Gothic UI", 9),
            bg='#2563eb',
            fg='#93c5fd'
        )
        subtitle_label.place(x=20, y=50)

        # ステータスバー
        self.status_frame = tk.Frame(self.root, bg='#e0e7ff', height=30)
        self.status_frame.pack(fill=tk.X)
        self.status_label = tk.Label(
            self.status_frame,
            text="✓ 接続済み  |  会話数: 0",
            font=("Yu Gothic UI", 9),
            bg='#e0e7ff',
            fg='#1e40af',
            anchor='w'
        )
        self.status_label.pack(side=tk.LEFT, padx=10, pady=5)

        # メインコンテナ
        main_container = tk.Frame(self.root, bg='#f0f2f5')
        main_container.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)

        # チャット表示エリア（カスタムキャンバス）
        chat_frame = tk.Frame(main_container, bg='white', relief=tk.FLAT)
        chat_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        self.canvas = tk.Canvas(chat_frame, bg='white', highlightthickness=0)
        scrollbar = tk.Scrollbar(chat_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg='white')
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # ウェルカムメッセージ
        self.add_welcome_message()

        # 入力エリア
        input_container = tk.Frame(main_container, bg='#f0f2f5')
        input_container.pack(fill=tk.X)
        input_frame = tk.Frame(input_container, bg='white', relief=tk.SOLID, bd=1)
        input_frame.pack(fill=tk.X)
        self.input_field = tk.Entry(
            input_frame,
            font=("Yu Gothic UI", 12),
            bg='white',
            fg='#1f2937',
            relief=tk.FLAT,
            insertbackground='#2563eb'
        )
        self.input_field.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=15, pady=12)
        self.input_field.bind("<Return>", lambda e: self.send_message())
        self.input_field.focus()
        self.send_button = tk.Button(
            input_frame,
            text="送信 ✈",
            command=self.send_message,
            font=("Yu Gothic UI", 11, "bold"),
            bg='#2563eb',
            fg='white',
            relief=tk.FLAT,
            padx=25,
            pady=10,
            cursor="hand2",
            activebackground='#1d4ed8',
            activeforeground='white'
        )
        self.send_button.pack(side=tk.RIGHT, padx=10, pady=5)
        hint_label = tk.Label(
            input_container,
            text="💡 Enterキーで送信  |  Ctrl+Lで履歴クリア  |  Ctrl+Sで会話保存",
            font=("Yu Gothic UI", 8),
            bg='#f0f2f5',
            fg='#6b7280'
        )
        hint_label.pack(pady=(5, 0))
        self.root.bind('<Control-l>', lambda e: self.clear_chat())
        self.root.bind('<Control-s>', lambda e: self.save_history())

    def add_welcome_message(self):
        welcome_frame = tk.Frame(self.scrollable_frame, bg='white')
        welcome_frame.pack(fill=tk.X, padx=20, pady=20)
        icon_label = tk.Label(
            welcome_frame,
            text="🤖",
            font=("Segoe UI Emoji", 40),
            bg='white'
        )
        icon_label.pack()
        title = tk.Label(
            welcome_frame,
            text="TERASS業務サポートAIへようこそ！",
            font=("Yu Gothic UI", 16, "bold"),
            bg='white',
            fg='#1f2937'
        )
        title.pack(pady=(10, 5))
        subtitle = tk.Label(
            welcome_frame,
            text="AIがあなたの業務をサポートします。お気軽にご質問ください。",
            font=("Yu Gothic UI", 10),
            bg='white',
            fg='#6b7280'
        )
        subtitle.pack(pady=(0, 15))
        # Quick question buttons
        quick_frame = tk.Frame(welcome_frame, bg='white')
        quick_frame.pack(pady=10)
        quick_questions = [
            "📋 手付金預かりの手順",
            "🏢 TERASS Picksの機能",
            "💰 最低金利の銀行",
            "🧭 シナリオ:手付金預かり",
            "🔑 Bitwarden利用方法",
            "🆘 ヘルプを見る"
        ]
        for i, q in enumerate(quick_questions):
            btn = tk.Button(
                quick_frame,
                text=q,
                font=("Yu Gothic UI", 9),
                bg='#eff6ff',
                fg='#1e40af',
                relief=tk.FLAT,
                padx=15,
                pady=8,
                cursor="hand2",
                command=lambda question=q: self.quick_question(question)
            )
            btn.pack(side=tk.LEFT, padx=5)

    def quick_question(self, question: str):
        """
        Handle quick question button clicks.  For regular questions, extract
        the query text and send it to the model.  For scenario buttons
        (containing 'シナリオ'), start the corresponding guided flow.
        """
        # Handle scenario triggers
        if "シナリオ" in question:
            scenario_name = "deposit_procedure"
            self.start_scenario(scenario_name)
            return
        # Show Bitwarden guide
        if "Bitwarden" in question:
            self.display_help_content('bitwarden_guide.md')
            return
        # Show general help
        if "ヘルプ" in question:
            # Combine bitwarden and packaging guide for a general overview
            self.display_help_content('bitwarden_guide.md', heading="Bitwarden Secrets Manager ガイド")
            self.display_help_content('packaging_guide.md', heading="アプリ配布ガイド")
            return
        # Otherwise treat as a standard informational query
        parts = question.split(' ', 1)
        query_text = parts[1] if len(parts) > 1 else question
        self.input_field.insert(0, query_text + "を教えて")
        self.send_message()

    def start_scenario(self, scenario_name: str) -> None:
        """Load the specified scenario and display each step sequentially."""
        steps = get_scenario(scenario_name)
        if not steps:
            self.add_message_bubble(
                "TERASS AI",
                f"シナリオ '{scenario_name}' が見つかりません。",
                is_user=False,
            )
            return
        self.add_message_bubble(
            "TERASS AI",
            f"🧭 {scenario_name} シナリオを開始します。順番にご確認ください。",
            is_user=False,
        )
        for step in steps:
            self.add_message_bubble("TERASS AI", step.prompt, is_user=False)

    def add_message_bubble(self, sender: str, message: str, is_user: bool = False) -> None:
        bubble_container = tk.Frame(self.scrollable_frame, bg='white')
        bubble_container.pack(fill=tk.X, padx=20, pady=10)
        if is_user:
            # Right‑aligned user message
            bubble_frame = tk.Frame(bubble_container, bg='white')
            bubble_frame.pack(side=tk.RIGHT)
            avatar = tk.Label(
                bubble_frame,
                text="👤",
                font=("Segoe UI Emoji", 20),
                bg='white'
            )
            avatar.pack(side=tk.RIGHT, padx=(10, 0))
            message_frame = tk.Frame(bubble_frame, bg='#2563eb', relief=tk.FLAT)
            message_frame.pack(side=tk.RIGHT)
            message_label = tk.Label(
                message_frame,
                text=message,
                font=("Yu Gothic UI", 11),
                bg='#2563eb',
                fg='white',
                wraplength=500,
                justify=tk.LEFT,
                padx=15,
                pady=10
            )
            message_label.pack()
        else:
            # Left‑aligned assistant message.  If a custom avatar
            # image has been loaded (see ``__init__``), use it; otherwise
            # fall back to an emoji icon.
            bubble_frame = tk.Frame(bubble_container, bg='white')
            bubble_frame.pack(side=tk.LEFT)
            if getattr(self, 'avatar_photo', None):
                avatar = tk.Label(
                    bubble_frame,
                    image=self.avatar_photo,
                    bg='white'
                )
                # Keep a reference to avoid garbage collection
                avatar.image = self.avatar_photo
            else:
                avatar = tk.Label(
                    bubble_frame,
                    text="🤖",
                    font=("Segoe UI Emoji", 20),
                    bg='white'
                )
            avatar.pack(side=tk.LEFT, padx=(0, 10))
            message_frame = tk.Frame(bubble_frame, bg='#f3f4f6', relief=tk.FLAT)
            message_frame.pack(side=tk.LEFT)
            message_label = tk.Label(
                message_frame,
                text=message,
                font=("Yu Gothic UI", 11),
                bg='#f3f4f6',
                fg='#1f2937',
                wraplength=550,
                justify=tk.LEFT,
                padx=15,
                pady=10
            )
            message_label.pack()
            timestamp = datetime.datetime.now().strftime('%H:%M')
            time_label = tk.Label(
                bubble_frame,
                text=timestamp,
                font=("Yu Gothic UI", 8),
                bg='white',
                fg='#9ca3af'
            )
            time_label.pack(side=tk.LEFT, padx=(10, 0))
        self.message_widgets.append(bubble_container)
        self.canvas.update_idletasks()
        self.canvas.yview_moveto(1.0)

    def send_message(self) -> None:
        user_message = self.input_field.get().strip()
        if not user_message:
            return
        # Check for missing API key before proceeding.  If the
        # ``OPENAI_API_KEY`` environment variable has not been set,
        # the OpenAI client will not function.  In that case we
        # immediately notify the user rather than attempting a
        # network call.  This helps beginners understand what
        # configuration step is required.  The API key can be
        # securely loaded via Bitwarden as described in the
        # ``bitwarden_guide.md`` document.
        if client.api_key is None:
            error_msg = (
                "APIキーが設定されていません。\n"
                "Bitwarden Secrets Manager に保存した OPENAI_API_KEY を読み込み、"
                "環境変数として設定してください。"
            )
            self.add_message_bubble("システム", error_msg, is_user=False)
            # Reset UI elements
            self.send_button.config(state=tk.NORMAL, text="送信 ✈")
            self.status_label.config(text="❌ APIキー未設定")
            return
        # Display user message
        self.add_message_bubble("あなた", user_message, is_user=True)
        self.input_field.delete(0, tk.END)
        # Disable button and update status
        self.send_button.config(state=tk.DISABLED, text="応答中 ⏳")
        self.status_label.config(text="⏳ 応答生成中...")
        self.root.update()
        try:
            # Append the user message to history for context
            self.conversation_history.append({"role": "user", "content": user_message})

            # Attempt to retrieve related documents to augment the system prompt
            context_str = self._get_rag_context(user_message)
            dynamic_system_prompt = self.system_prompt
            if context_str:
                dynamic_system_prompt += "\n\n# 関連資料\n" + context_str

            # Construct the message list: include only the most recent exchanges
            messages = [
                {"role": "system", "content": dynamic_system_prompt}
            ] + self.conversation_history[-10:]

            # Call OpenAI chat completion
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=messages,
                temperature=0.7,
                max_tokens=2000
            )
            ai_response = response.choices[0].message.content  # type: ignore
            # Display assistant response
            self.add_message_bubble("TERASS AI", ai_response, is_user=False)
            # Save assistant message to history
            self.conversation_history.append({"role": "assistant", "content": ai_response})
            # Keep history to last 20 messages
            if len(self.conversation_history) > 20:
                self.conversation_history = self.conversation_history[-20:]
            # Update status with conversation count
            conv_count = len([m for m in self.conversation_history if m["role"] == "user"])
            self.status_label.config(text=f"✓ 接続済み  |  会話数: {conv_count}")
        except Exception as e:
            error_msg = (
                f"エラーが発生しました:\n{str(e)}\n\n確認事項:\n1. インターネット接続\n2. APIキーの有効性"
            )
            self.add_message_bubble("システム", error_msg, is_user=False)
            self.status_label.config(text="❌ エラー発生")
        finally:
            self.send_button.config(state=tk.NORMAL, text="送信 ✈")
            self.input_field.focus()

    def clear_chat(self) -> None:
        if messagebox.askyesno("確認", "会話履歴をクリアしますか？"):
            for widget in self.message_widgets:
                widget.destroy()
            self.message_widgets = []
            self.conversation_history = []
            self.add_welcome_message()
            self.status_label.config(text="✓ 接続済み  |  会話数: 0")

    def save_history(self) -> None:
        try:
            with open('chat_history.json', 'w', encoding='utf-8') as f:
                json.dump(self.conversation_history, f, ensure_ascii=False, indent=2)
            self.status_label.config(text="💾 会話を保存しました")
            self.root.after(2000, lambda: self.status_label.config(text="✓ 接続済み"))
        except Exception as e:
            messagebox.showerror("エラー", f"保存に失敗しました:\n{str(e)}")

    def load_history(self) -> None:
        try:
            if os.path.exists('chat_history.json'):
                with open('chat_history.json', 'r', encoding='utf-8') as f:
                    self.conversation_history = json.load(f)
        except Exception:
            pass

    def display_help_content(self, filename: str, heading: str | None = None) -> None:
        """
        Read a local Markdown file and display its content in the chat.

        This helper is used by quick question buttons to provide static
        documentation (e.g. Bitwarden usage or packaging guides).  The
        provided ``filename`` should exist in the same directory as
        this script.  Optionally a heading can be specified to
        introduce the content.
        """
        try:
            base_dir = os.path.dirname(__file__)
            path = os.path.join(base_dir, filename)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            if heading:
                content = f"### {heading}\n\n" + text
            else:
                content = text
            self.add_message_bubble("TERASS AI", content, is_user=False)
            # Also append to history for persistent logs
            self.conversation_history.append({"role": "assistant", "content": content})
        except Exception as e:
            self.add_message_bubble("システム", f"ヘルプファイルの読み込みに失敗しました: {e}", is_user=False)

    # RAG helper methods
    def _get_rag_context(self, query: str, top_k: int = 2) -> str:
        """
        Retrieve relevant document excerpts for the given user query.

        If the RAG subsystem has been initialised, this method
        searches the indexed documents and returns a short formatted
        string containing the most relevant excerpts and their source
        filenames.  If RAG is unavailable, it returns an empty
        string.

        Parameters
        ----------
        query: str
            The user's query string.
        top_k: int
            Number of top results to include.

        Returns
        -------
        context: str
            A formatted context string or an empty string when no
            relevant documents are found.
        """
        if not self._rag_ready or not self._rag_vectorizer:
            return ""
        try:
            results = query_documents(
                query,
                self._rag_vectorizer,
                self._rag_matrix,
                self._rag_texts,
                self._rag_meta,
                top_k=top_k,
            )
            context_lines = []
            for text, meta in results:
                # Extract the first 400 characters of the document as a preview
                snippet = text.strip().replace('\n', ' ')
                snippet = snippet[:400] + ('...' if len(snippet) > 400 else '')
                # Show only the filename (without full path) in the context
                source_name = os.path.basename(meta.get('source', ''))
                context_lines.append(f"【{source_name}】 {snippet}")
            return "\n".join(context_lines)
        except Exception:
            return ""


if __name__ == "__main__":
    root = tk.Tk()
    app = ModernTERASSAssistant(root)
    root.mainloop()