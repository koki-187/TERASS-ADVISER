import React from 'react';
import { ScrollView, Text, StyleSheet, useColorScheme } from 'react-native';

/**
 * DevMemoScreen
 *
 * この画面では、iOS 版 TERASS 業務サポートAI の開発状況をまとめています。
 * 実装済み機能や今後の課題などを一覧で確認できます。将来的に新しい機能が
 * 追加された際は、ここに追記しておきましょう。
 */
export default function DevMemoScreen() {
  const scheme = useColorScheme();
  const containerStyle = [
    styles.container,
    { backgroundColor: scheme === 'dark' ? '#000' : '#fff' },
  ];
  return (
    <ScrollView style={containerStyle} contentInsetAdjustmentBehavior="automatic">
      <Text style={styles.title}>開発メモ</Text>
      <Text style={styles.paragraph}>
        現時点で実装されている主な機能:
        {'\n'}• チャットUIと自然な対話ができる AI アシスタント
        {'\n'}• 手付金預かりの 14 ステップに沿ったシナリオ誘導
        {'\n'}• OpenAI API 連携による回答生成とエラー処理
        {'\n'}• 簡易 RAG 検索でナレッジベースから関連資料を検索
        {'\n'}• サーバーが配信する最新の資料JSONを取得する仕組み
        {'\n'}• Bitwarden Secrets Manager を利用した安全な秘密情報の管理
        {'\n'}• オフラインで閲覧できる FAQ 画面
      </Text>
      <Text style={styles.paragraph}>
        今後の課題や発展的なアイデア:
        {'\n'}• ベクタDBを用いた高度な検索機能の統合（サーバー側APIが必要）
        {'\n'}• 自動スクレイピングによる最新データ収集をサーバー側で実行し、
        モバイルアプリへ連携する仕組み
        {'\n'}• UI/UX の細部調整（ダークモード対応、入力時の補助機能など）
        {'\n'}• ビルドと配布を自動化する CI/CD パイプラインの整備
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  paragraph: {
    fontSize: 16,
    lineHeight: 22,
    marginBottom: 16,
  },
});