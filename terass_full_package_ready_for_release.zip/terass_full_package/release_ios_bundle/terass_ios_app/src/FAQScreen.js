import React from 'react';
import { ScrollView, Text, StyleSheet, useColorScheme } from 'react-native';

/**
 * FAQScreen
 *
 * よく寄せられる質問とその回答を一覧表示します。ネットワーク接続がない場合でも
 * アプリ内で基本的なガイダンスを確認できるよう、あらかじめ内容を埋め込んでいます。
 */
export default function FAQScreen() {
  const scheme = useColorScheme();
  const containerStyle = [
    styles.container,
    { backgroundColor: scheme === 'dark' ? '#000' : '#fff' },
  ];
  return (
    <ScrollView style={containerStyle} contentInsetAdjustmentBehavior="automatic">
      <Text style={styles.title}>よくある質問 (FAQ)</Text>
      {/* 質問1 */}
      <Text style={styles.question}>Q1: Bitwarden Secrets Manager とは何ですか？</Text>
      <Text style={styles.answer}>
        A1: Bitwarden は、ユーザー名やパスワード、APIキーなどの機密情報を暗号化して安全に保存する
        クラウドベースのサービスです。TERASS 業務サポートAIでは、OpenAI APIキーや
        業務システムのログイン情報をコードに直接書き込まずに利用できるよう、Bitwarden を介して
        読み出しています。
      </Text>

      {/* 質問2 */}
      <Text style={styles.question}>Q2: このアプリを使うためにターミナル操作は必要ですか？</Text>
      <Text style={styles.answer}>
        A2: いいえ、利用者がターミナルにコマンドを入力する必要はありません。アプリには必要な
        APIキーや設定が事前に注入されており、起動するだけでご利用いただけます。開発者は
        Bitwarden CLIやGitHub Actionsを用いて秘密情報を管理しますが、エンドユーザーは意識
        する必要はありません。
      </Text>

      {/* 質問3 */}
      <Text style={styles.question}>Q3: チャットボットはどのように情報を取得していますか？</Text>
      <Text style={styles.answer}>
        A3: ユーザーの質問は OpenAI のチャットAPIに送信され、アプリ内のナレッジベースから
        関連する資料を検索してコンテキストとして渡しています。これにより、業務に必要な
        情報を含んだ自然な回答が返ってきます。ナレッジベースは定期的に更新可能です。
      </Text>

      {/* 質問4 */}
      <Text style={styles.question}>Q4: 最新のデータはどこから取得されていますか？</Text>
      <Text style={styles.answer}>
        A4: iOS版では、サーバー側で配信する最新の資料JSONを読み込み、アプリ内のデータを
        更新する仕組みを取り入れています。Scraping を端末内で行うことはありません。
      </Text>

      {/* 質問5 */}
      <Text style={styles.question}>Q5: 問題や不具合があった場合はどうすればよいですか？</Text>
      <Text style={styles.answer}>
        A5: アプリの動作に問題がある場合は、担当者やサポート窓口にお問い合わせください。
        可能であれば、エラー時の画面や状況を記録してお伝えいただくと、調査がスムーズに進みます。
      </Text>

      {/* 質問6 */}
      <Text style={styles.question}>Q6: ダークモードに対応していますか？</Text>
      <Text style={styles.answer}>
        A6: はい、iOS の外観設定がダークモードの場合は画面の背景色が自動的に暗い色に切り替わります。
        明るいモードでは白背景になりますので、お好みに合わせて設定をご確認ください。
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  question: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 12,
    marginBottom: 4,
  },
  answer: {
    fontSize: 16,
    lineHeight: 22,
    marginBottom: 8,
  },
});