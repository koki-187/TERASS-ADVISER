// src/config.js
//
// このファイルでは、外部APIに関する設定やキーを定義します。
// iOS版ではコマンドラインでの設定を行わずにすむよう、
// ビルド時に自動で値が注入されることを想定しています。
// 実際の運用では .env ファイルや Bitwarden Secrets Manager など
// セキュアな方法から API キーを提供してください。

// OpenAI API キー。ビルドプロセスで安全に置き換えられるようプレースホルダを設定します。
export const OPENAI_API_KEY = '<YOUR_OPENAI_API_KEY>';

// OpenAI チャット・コンプリーション API エンドポイント
export const OPENAI_API_ENDPOINT = 'https://api.openai.com/v1/chat/completions';

// RAG用の最新ナレッジAPIエンドポイント。
// デスクトップ版ではベクタDBを利用していますが、iOS版ではサーバー側で最新データをJSONで提供する仕組みを推奨しています。
// デフォルトは空文字列としておき、設定しない場合はアプリ内の埋め込みナレッジのみを使用します。
export const KNOWLEDGE_API_URL = '';

// ベクタDB検索APIのエンドポイント。
// デスクトップ版のベクタDB検索をモバイルから利用するために使用します。
// 空文字列の場合はベクタ検索を行いません。
export const VECTOR_API_URL = '';