// src/openai.js
//
// OpenAI API にアクセスする関数を定義します。
// fetchOpenAIResponse() はユーザーの入力とシステムメッセージ（コンテキスト）を受け取り、
// ChatCompletion API を呼び出してアシスタントの返答を取得します。
// 実際の API 呼び出しにはネットワーク接続が必要ですが、
// このコードはインターフェースとして記述しておきます。

import { OPENAI_API_KEY, OPENAI_API_ENDPOINT } from './config';

/**
 * OpenAI ChatCompletion API を呼び出して応答を取得します。
 * @param {string} prompt ユーザーの入力
 * @param {Array} systemContext システムプロンプトや過去コンテキストの配列
 * @returns {Promise<string>} アシスタントの返答テキスト
 */
export async function fetchOpenAIResponse(prompt, systemContext = []) {
  // API キーが設定されていない場合は警告を出力
  if (!OPENAI_API_KEY || OPENAI_API_KEY.startsWith('<')) {
    console.warn('OpenAI API キーが設定されていません。config.js を更新してください。');
    return 'エラー：API キーが設定されていません。';
  }
  const messages = [...systemContext, { role: 'user', content: prompt }];
  const body = {
    model: 'gpt-4o',
    messages,
    temperature: 0.5,
  };
  try {
    const response = await fetch(OPENAI_API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify(body),
    });
    const data = await response.json();
    if (data.choices && data.choices.length > 0) {
      return data.choices[0].message.content.trim();
    }
    return 'エラー：OpenAI API から有効な応答が得られませんでした。';
  } catch (error) {
    console.error('OpenAI API 呼び出しエラー:', error);
    return 'エラー：OpenAI API への接続に失敗しました。';
  }
}