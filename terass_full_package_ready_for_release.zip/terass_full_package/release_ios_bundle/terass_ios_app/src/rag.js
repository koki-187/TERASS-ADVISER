// src/rag.js
//
// 簡易的な資料検索（RAG）のためのモジュールです。
// デスクトップ版では外部ベクタDBに埋め込まれたナレッジから検索しますが、
// iOS版では埋め込み済みのテキストを対象に簡易検索を行います。
// ユーザーの質問に含まれるキーワードをもとに各資料を検索し、
// 該当する部分の抜粋を返します。

// 既定のドキュメントデータ。
// デスクトップ版のように外部ベクタDBを使用しないため、
// 初期状態ではアプリ内に埋め込まれたナレッジを検索対象とします。
// fetchLatestDocs() で外部JSONを読み込んだ場合、このオブジェクトに上書きされます。
const docs = {
  'Loan Checker': `対応金融機関: 107行（メガバンク / ネット銀行 / 地方銀行 / 信用金庫 / その他）\n金利レンジ: 0.520% ～ 3.242%\n変動金利対応: 93行、固定金利対応: 9行\n提案ロジック:\n・顧客属性（年収、借入額、勤続年数、希望金利タイプ）を入力\n・対応可能な金融機関をフィルタリングし、金利・返済プランを提示\n・APIで金利の最新値を定期取得してキャッシュ`,
  'TERASS Picks': `データソース: SUUMO, at HOME, REINS\n更新頻度: REINS 1日4回、SUUMO / at HOME 1日1回\n自己発見案件として扱い（報酬75〜90%）\n2025年最新機能: 共有アカウント（2025-10-16）、学区・ハザード情報（2025-10-06）、販売図面アップロード（2025-10-06）\n機能: 統合検索API、物件紹介テンプレート、リアクション機能`,
  'Adviser Spec': `報酬体系: 基本報酬75%〜90%、本部送客40%、Terass Offer 55%、など。\nAgent Class: Premier / Senior / Expert / Lead / Terass Agent (Tier1/2/3) / Junior、売上基準や特典を定める。\nTERASS Picks: SUUMO / at HOME / REINS を統合検索。更新頻度: REINS 1日4回、SUUMO/at HOME 1日1回。自己発見扱い。\n住宅ローン機能: 107金融機関対応、金利0.520%-3.242%、変動93、固定9。Loan Checkerと統合。\n12セクション構造: 参画後確認、社内ルール、営業ツール、集客、契約、提携先、ナレッジ、売上向上ヒント、オンボーディング、Branch情報、Agent Well-being、収益・事業用向け。`,
  'Knowledge Base': `手付金預かり手順（14ステップ）: 本人確認、契約書作成、重要事項説明、手付金確認、預かり証準備、手付金受領、預かり証発行、TERASS Cloud登録、保全措置確認、本部報告、記録保管、決済日管理、手付金充当、完了報告。\nTERASS Picks: 284,096件の物件データ、学区やハザード情報表示、2025年に共有アカウントや販売図面アップロード機能追加。\nTERASS特別金利ローン: 物件価格の90%まで借入可能、変動金利0.55〜1.465%、ペアローンは最大12億円、返済期間1〜50年、キャンペーンあり。\nTerass Insight: AI評価でライフスタイルに合った住まいを提案、面談依頼や物件検索リンク発行をサポート。\nLoan Checker: 最適ローン商品を提案。\nAgent Class報酬: 初心者からChairmanまで報酬率75-90%。\n役所調査カテゴリー: 都市計画、建築基準法、道路、上下水道、埋蔵文化財、その他。\nその他注意点: 同一メールアドレスでログイン、環境変数を安全に管理。`,
};

/**
 * 外部エンドポイントから最新のナレッジを取得して docs オブジェクトに上書きします。
 * エンドポイントは JSON オブジェクト（キー: 資料名、値: 内容）を返すことを前提とします。
 * 例: { "Loan Checker": "...", "TERASS Picks": "..." }
 * この関数は実行時に例外を投げません。失敗した場合は console.warn にエラーを出力します。
 * @param {string} url ナレッジを取得するHTTP(S)エンドポイント
 */
export async function fetchLatestDocs(url) {
  try {
    const res = await fetch(url);
    if (!res || !res.ok) {
      console.warn('ナレッジ取得に失敗しました: ', res && res.status);
      return;
    }
    const data = await res.json();
    if (data && typeof data === 'object') {
      Object.keys(data).forEach(key => {
        docs[key] = data[key];
      });
    } else {
      console.warn('ナレッジ形式が不正です');
    }
  } catch (err) {
    console.warn('ナレッジ取得時にエラーが発生しました: ', err);
  }
}

/**
 * キーワードに基づいて資料を検索します。
 * @param {string} query 検索するキーワード
 * @returns {Array<{name: string, snippet: string}>} 該当する資料名と抜粋の配列
 */
export function queryDocs(query) {
  const lower = query.toLowerCase();
  const results = [];
  Object.entries(docs).forEach(([name, content]) => {
    const idx = content.toLowerCase().indexOf(lower);
    if (idx >= 0) {
      // 見つかった位置から前後100文字を抜粋
      const start = Math.max(0, idx - 50);
      const end = Math.min(content.length, idx + 150);
      const snippet = content.substring(start, end);
      results.push({ name, snippet });
    }
  });
  // 該当件数がない場合は空配列
  return results.slice(0, 2);
}