import React from 'react';
import { ScrollView, Text, StyleSheet, TouchableOpacity, useColorScheme } from 'react-native';
import { useNavigation } from '@react-navigation/native';

/**
 * HelpScreen
 *
 * この画面では、Bitwarden Secrets Manager の概要と安全な利用方法を簡単に説明します。
 * アプリ内からいつでもアクセスできるようにすることで、初心者の方でも安心して設定を確認できます。
 */
export default function HelpScreen() {
  // useNavigation フックを利用してナビゲーションオブジェクトを取得します。
  const navigation = useNavigation();
  // ダークモード対応: 色のテーマを取得します。
  const scheme = useColorScheme();
  const containerStyle = [
    styles.container,
    { backgroundColor: scheme === 'dark' ? '#000' : '#fff' },
  ];
  return (
    <ScrollView style={containerStyle} contentInsetAdjustmentBehavior="automatic">
      <Text style={styles.title}>ヘルプ・ガイド</Text>
      <Text style={styles.paragraph}>
        TERASS 業務サポートAIでは、OpenAI API キーなどの機密情報を安全に管理するために
        Bitwarden Secrets Manager を使用しています。Bitwarden とは、ユーザー名や
        パスワード、API キーなどを暗号化して保存し、必要なときにだけ取り出せる金庫のようなサービスです。
      </Text>
      <Text style={styles.paragraph}>
        アプリの開発者は Bitwarden CLI を使って秘密情報を注入しますが、利用者がこのアプリを
        使用する際にターミナル操作は必要ありません。アプリには必要なキーが事前に組み込まれており、
        セキュアな状態で実行されますので安心してご利用ください。
      </Text>
      <Text style={styles.paragraph}>
        Bitwarden の詳細や使い方については、公式ヘルプページ
        (https://bitwarden.com/help/) を参照してください。
      </Text>
      {/* FAQ画面へのリンクボタン */}
      <TouchableOpacity onPress={() => navigation.navigate('FAQ')}>
        <Text style={styles.link}>よくある質問を表示する</Text>
      </TouchableOpacity>

      {/* 開発メモ画面へのリンクボタン */}
      <TouchableOpacity onPress={() => navigation.navigate('DevMemo')}>
        <Text style={styles.link}>開発メモを表示する</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  paragraph: {
    fontSize: 16,
    lineHeight: 22,
    marginBottom: 12,
  },
  link: {
    fontSize: 16,
    color: '#007AFF',
    marginTop: 16,
  },
});