# TERASS 業務サポートAI – iOS アプリ開発ガイド

このディレクトリには、TERASS 業務サポートAI を iOS でも利用できるようにするためのソースコードとガイドラインが含まれています。React Native (Expo) を用いてチャット UI やシナリオ誘導、OpenAI API 連携を実装済みで、モバイル環境に合わせた UI/UX が整っています。

## 🎯 開発方針

- **開発環境**：React Native (Expo) や SwiftUI などを使用してネイティブアプリを構築する方法があります。本ガイドではクロスプラットフォームで開発しやすい React Native (Expo) を前提としています。
- **AI 連携**：デスクトップ版と同様に OpenAI API を利用して回答を生成します。API キーやログイン情報は Bitwarden Secrets Manager で管理し、ビルド時に自動で注入されることを想定しています。
- **UI デザイン**：デスクトップ版のチャットUIを参考に、モバイル向けに最適化したチャット画面を作成します。`assets/` ディレクトリにアイコンやアバター、ダッシュボード風の参考画像が含まれています。

## 📁 ディレクトリ構成

```
terass_ios_app/
├── App.js               … アプリのエントリーポイント。チャット画面とヘルプ画面を定義したナビゲーションを構築します。
├── app.json             … Expo 向け設定ファイル。アプリ名やアイコン、iOS のバンドルIDなどを記載しています。
├── package.json         … 依存ライブラリと実行スクリプトを定義します。
├── assets/              … アプリ内で使用するアイコンやアバター画像。
│   ├── final_icon.png   … メタリックシルバー枠付きの最終アイコン（iOS/デスクトップ共通）。
│   ├── icon_pattern_a.png, icon_pattern_b.png, icon_pattern_c.png … インタラクティブアイコンの別バリエーション。
│   ├── terass_avatar.png … チャットUIで使用するアバター画像。
│   └── terass_icon.ico    … ICO 形式のアイコン（参考）。
└── src/
    ├── ChatScreen.js     … チャット画面。GiftedChat を用いて会話を表示し、OpenAI API 連携やシナリオ誘導を行います。
    ├── HelpScreen.js     … ヘルプ画面。Bitwarden Secrets Manager の概要と安全な利用方法を説明しています。
    ├── FAQScreen.js      … よくある質問画面。オフラインで閲覧できるQ&Aをまとめています。
    ├── DevMemoScreen.js  … 開発メモ画面。実装済み機能や今後の課題をまとめています。
    ├── scenarios.js      … 「手付金預かり手順」の14ステップを定義したシナリオモジュール。
    ├── openai.js         … OpenAI ChatCompletion API へ問い合わせる関数を定義します。
    └── config.js         … APIキーやエンドポイントを定義する設定ファイル。
```

## 🚀 開発・配布のステップ

このプロジェクトには既にチャットUIと AI 機能が実装済みです。以下の手順に従うことで、ソースコードをビルドし、テストや公開に向けた準備ができます。

### フェーズ1：環境構築

1. **React Native (Expo) の準備**
   
   [React Native 環境構築ガイド](https://reactnative.dev/docs/environment-setup) に沿って開発環境を整えます。Expo CLI を使用する場合、次のコマンドでインストールできます。
   
   ```bash
   npm install --global expo-cli
   ```

2. **依存ライブラリのインストール**

   プロジェクトのルートに移動し、以下のコマンドで必要なパッケージをインストールします。
   
   ```bash
   cd terass_ios_app
   npm install
   ```

### フェーズ2：AI機能とデータ連携

1. **OpenAI API キーの設定**

   `src/config.js` には `OPENAI_API_KEY` というプレースホルダが含まれています。CI/CD（GitHub Actions）や Bitwarden Secrets Manager でビルド時に安全にキーを注入できるよう、コードでは直接キーを記述していません。開発中に手動で試す場合は、ここに一時的にキーを設定してください。公開時は必ず秘密情報を環境変数から読み込ませる仕組みを利用します。

2. **シナリオ誘導の拡張**

   `src/scenarios.js` には「手付金預かり手順」の14ステップが定義されています。必要に応じて他の業務シナリオを追加し、`ChatScreen.js` で条件分岐を増やすことで対話の誘導を実現できます。

3. **データ検索（RAG）の実装**

   - **簡易検索**：本アプリには `src/rag.js` で定義した資料検索関数 `queryDocs` があり、埋め込まれたナレッジからキーワード検索を行います。

   - **最新データの取得**：デスクトップ版ではベクタDBやスクレイピングで最新情報を取得していますが、モバイル版では代わりにサーバー側で最新資料を JSON として配信し、それを取得する方式を推奨します。`src/rag.js` には `fetchLatestDocs(url)` が用意されており、`src/config.js` の `KNOWLEDGE_API_URL` にエンドポイントを設定すると起動時に自動で最新ナレッジを読み込みます。

   - **ベクタ検索の利用**：デスクトップ版のようにベクタDBを用いた検索を行いたい場合は、サーバー側に検索APIを用意し、`src/vectorSearch.js` の `searchVectorDocs` を通じて呼び出せます。`src/config.js` の `VECTOR_API_URL` にエンドポイントを設定すると、チャットでの回答時にベクタ検索結果が表示されます。空のままにすると検索は行われません。

   - **エンドポイントの例**：社内で Notion API や Google Drive API を利用して最新資料を JSON 形式でまとめ、公開URLに配置します。CI で定期的に更新し、そのURLをアプリの `KNOWLEDGE_API_URL` に設定することで、スクレイピングを行わずにデータが更新されます。

### フェーズ3：UI/UX 改善と配布準備

1. **UI/UX の仕上げ**

   - **カラースキーム**：iOS のダークモード / ライトモードに対応するため、背景色や文字色を `Appearance` API と連携させることを検討します。
   - **ヘルプ画面**：`HelpScreen.js` で Bitwarden の説明を表示しています。初心者が迷わないよう、必要に応じてスクロール可能な FAQ や連絡先を追加することもできます。
   - **FAQ 画面**：`FAQScreen.js` にはよくある質問と回答があらかじめ埋め込まれており、ネットワーク接続がなくても基本的なガイダンスを参照できます。ヘルプ画面のリンクからアクセスできます。
   - **開発メモ画面**：`DevMemoScreen.js` では、実装済み機能や今後の課題を一覧できます。プロジェクトの進捗を共有するための備忘録として活用してください。
   - **アイコンと起動画面**：`app.json` で `icon` と `splash` を指定しており、`final_icon.png` がアプリのアイコンとスプラッシュ画面に使われます。Apple のガイドラインに沿って必要に応じてサイズを調整してください。

2. **ビルドとテスト**

   - **Expo Go でテスト**：開発中は `expo start` で QR コードを読み取り、iPhone 上でアプリを確認できます。
   - **アプリのビルド**：アプリを配布するには Expo の [EAS Build](https://expo.dev/eas) か、Xcode を使ったビルドが必要です。例えば EAS を使う場合、以下のように iOS 用の `.ipa` ファイルを生成します。

     ```bash
     npm install --global eas-cli
     eas build -p ios --profile production
     ```

     生成された `.ipa` ファイルは TestFlight や Apple Business Manager を通じて配布できます。エンドユーザーはターミナル操作なしでアプリをインストールできます。

3. **秘密情報と環境変数の管理**

   Bitwarden Secrets Manager を利用する場合は、デスクトップ版の `bitwarden_guide.md` に記載の方法でシークレットを登録し、CI のビルドステップで `Config.xcconfig` に注入する仕組みを利用してください。これにより、エンドユーザーがアプリをインストールする際にターミナル操作をする必要はありません。

開発者向けの詳しい設定やカスタマイズ方法は、React Native と Expo の公式ドキュメントを参照してください。初心者が迷わないよう、用語の解説やサンプルコードを README 内に盛り込んでいますので、プロジェクトの理解にお役立てください。