import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import ChatScreen from './src/ChatScreen';
import HelpScreen from './src/HelpScreen';
import FAQScreen from './src/FAQScreen';
import DevMemoScreen from './src/DevMemoScreen';
import { TouchableOpacity, Text } from 'react-native';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Chat">
        <Stack.Screen
          name="Chat"
          component={ChatScreen}
          options={({ navigation }) => ({
            title: 'チャット',
            headerRight: () => (
              <TouchableOpacity onPress={() => navigation.navigate('Help')}>
                <Text style={{ marginRight: 16, color: '#007AFF', fontSize: 16 }}>ヘルプ</Text>
              </TouchableOpacity>
            ),
          })}
        />
        <Stack.Screen name="Help" component={HelpScreen} options={{ title: 'ヘルプ' }} />
        {/* FAQ 画面をナビゲーションに追加 */}
        <Stack.Screen name="FAQ" component={FAQScreen} options={{ title: 'FAQ' }} />
        {/* 開発メモ 画面をナビゲーションに追加 */}
        <Stack.Screen name="DevMemo" component={DevMemoScreen} options={{ title: '開発メモ' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}