import puppeteer from "puppeteer";

/**
 * 各サイトのログインと更新履歴の抽出をまとめて実行
 * 必要に応じてセレクタやURLを調整してください。
 */
export async function runAll() {
  const browser = await puppeteer.launch({
    headless: true,
    args: ["--no-sandbox","--disable-setuid-sandbox"]
  });
  const page = await browser.newPage();
  const result = {};

  // 1) TERASS Cloud
  result.cloud = await collectTerassCloud(page);

  // 2) TERASS PICKS
  result.picks = await collectTerassPicks(page);

  // 3) Notion（画面スクレイピング）
  result.notion = await collectNotion(page);

  await browser.close();
  return result;
}

// --- 以下は雛形。実際の入力フォーム名・セレクタに合わせて調整してください。 ---

async function collectTerassCloud(page) {
  console.log("🔐 TERASS Cloud login...");
  await page.goto("https://agent-cloud.terass.com/s/login", { waitUntil: "networkidle0" });
  await page.type('input[name="username"]', process.env.TERASS_CLOUD_USER);
  await page.type('input[name="password"]', process.env.TERASS_CLOUD_PASS);
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: "networkidle0" })
  ]);
  console.log("➡️  Fetch updates...");
  // 仮セレクタ（例）：.update-item の各要素から date/title/link を抽出
  const updates = await page.$$eval(".update-item", items => items.map(el => ({
    date: el.querySelector(".update-date")?.textContent?.trim() || "",
    title: el.querySelector(".update-title")?.textContent?.trim() || "",
    link: el.querySelector("a")?.href || ""
  })));
  return { count: updates.length, items: updates.slice(0, 10) };
}

async function collectTerassPicks(page) {
  console.log("🔐 TERASS PICKS login...");
  await page.goto("https://picks-agent.terass.com/login", { waitUntil: "networkidle0" });
  await page.type('input[name="email"]', process.env.TERASS_PICKS_USER);
  await page.type('input[name="password"]', process.env.TERASS_PICKS_PASS);
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: "networkidle0" })
  ]);
  console.log("➡️  Fetch updates...");
  const updates = await page.$$eval(".update-item", items => items.map(el => ({
    date: el.querySelector(".update-date")?.textContent?.trim() || "",
    title: el.querySelector(".update-title")?.textContent?.trim() || "",
    link: el.querySelector("a")?.href || ""
  })));
  return { count: updates.length, items: updates.slice(0, 10) };
}

async function collectNotion(page) {
  console.log("🔐 Notion login...");
  await page.goto("https://www.notion.so/login", { waitUntil: "networkidle0" });
  await page.type('input[type="email"]', process.env.NOTION_EMAIL);
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForSelector('input[type="password"]', { timeout: 30000 })
  ]);
  await page.type('input[type="password"]', process.env.NOTION_PASSWORD);
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: "networkidle0" })
  ]);

  // 対象ページへ遷移
  await page.goto(process.env.NOTION_PAGE_URL, { waitUntil: "networkidle0" });

  console.log("➡️  Fetch updates block...");
  // 例：見出しテキスト「更新情報」や「Notion更新情報」などを含むブロック近傍を抽出する簡易版
  const text = await page.evaluate(() => document.body.innerText);
  // 実装では $$eval / $x などで見出し→次要素のリスト抽出に寄せる
  const first1000 = text.split("\n").slice(0, 200).join("\n");
  return { preview: first1000.substring(0, 1000) };
}
