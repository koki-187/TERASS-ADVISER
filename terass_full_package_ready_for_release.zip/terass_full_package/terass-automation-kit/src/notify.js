// 任意：Slack等への通知を実装する場合の雛形
export async function notifyNewUpdates(items) {
  // TODO: Incoming Webhook などにPOST
  console.log("🛎️ New updates:", items.length);
}
