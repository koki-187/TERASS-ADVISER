import dotenv from "dotenv";
import { runAll } from "./scraper.js";
dotenv.config();

(async () => {
  try {
    const result = await runAll();
    console.log("✅ Finished:", JSON.stringify(result, null, 2));
  } catch (e) {
    console.error("❌ Error:", e?.message || e);
    process.exit(1);
  }
})();