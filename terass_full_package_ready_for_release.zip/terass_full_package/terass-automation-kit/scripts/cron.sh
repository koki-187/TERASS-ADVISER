#!/usr/bin/env bash
set -euo pipefail

# === 1) Bitwarden Secrets Manager Access Token を設定 ===
export BW_SM_ACCESS_TOKEN="__REPLACE_WITH_YOUR_TOKEN__"

# === 2) 実行（Secrets を ENV に注入して Node を起動） ===
# 例：/usr/local/bin/node のパスは環境に合わせて変更してください
/usr/local/bin/bws exec   --env OPENAI_API_KEY   --env TERASS_CLOUD_USER --env TERASS_CLOUD_PASS   --env TERASS_PICKS_USER --env TERASS_PICKS_PASS   --env NOTION_EMAIL --env NOTION_PASSWORD --env NOTION_PAGE_URL   -- /usr/local/bin/node "$(dirname "$0")/../src/index.js" >> /var/log/terass-automation.log 2>&1
