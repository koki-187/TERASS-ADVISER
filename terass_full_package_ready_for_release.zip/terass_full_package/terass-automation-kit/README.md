# TERASS Automation Kit (Bitwarden Secrets Manager + CI/CD + Cron)

このキットは、**GitHub Actions / Cron** で「人手不要」に動作する更新収集システムを最短で構築できる雛形です。  
秘密は **Bitwarden Secrets Manager** から **実行時に注入** し、コードや Git に残しません。

## 1. 使い方（最短）

### A. GitHub Actions で動かす
1. リポジトリの **Settings > Secrets and variables > Actions** に `BW_SM_ACCESS_TOKEN` を追加。  
2. `workflows/ci-deploy.yml` をそのまま使う（ブランチ名や Node バージョンは必要に応じて変更）。  
3. `src/index.js` が定期的に `process.env` から秘密を受け取り、スクレイピングを実行します。

### B. Cron（自前サーバ）で動かす
1. サーバに **bws（Secrets Manager CLI）** をインストール。  
2. `scripts/cron.sh` のトークンとパスと Node 実行パスを自環境に合わせて編集。  
3. `crontab -e` で `0 3 * * * /path/to/scripts/cron.sh` のように登録。

---

## 2. Secrets の設計（Bitwarden Secrets Manager）

Secrets Manager の Project に以下のキーを登録します（値はあなたの環境のもの）：

- `OPENAI_API_KEY`
- `TERASS_CLOUD_USER`, `TERASS_CLOUD_PASS`
- `TERASS_PICKS_USER`, `TERASS_PICKS_PASS`
- `NOTION_EMAIL`, `NOTION_PASSWORD`, `NOTION_PAGE_URL`

> GitHub Actions では `BW_SM_ACCESS_TOKEN` を **Actions Secrets** に保存します。  
> Cron では `scripts/cron.sh` で `export BW_SM_ACCESS_TOKEN=...` として設定します。

---

## 3. フォルダ構成

```
terass-automation-kit/
├─ src/
│  ├─ index.js        # 実行エントリ
│  ├─ scraper.js      # ログイン＆更新収集の雛形（Puppeteer）
│  └─ notify.js       # 通知（Slackなど）の雛形
├─ scripts/
│  └─ cron.sh         # Cron 実行用スクリプト
├─ workflows/
│  └─ ci-deploy.yml   # GitHub Actions
├─ .env.example       # 値なしテンプレート（共有用）
├─ .gitignore
└─ README.md
```

---

## 4. 重要な運用ポイント

- `.env` は **Git に含めない**（`.gitignore` 同梱）。共有は `.env.example` のみ。  
- 自動化は **Secrets 注入で完結**。SSH は「人の Git 作業」用にのみ使用（任意）。  
- セレクタ変更等でスクレイピングが失敗する場合は `src/scraper.js` の `selectUpdates*` を調整。  
- ログや通知に **秘密情報を出力しない** ように注意。

---

## 5. ライセンス / クレジット

この雛形はプロジェクト内部利用を想定しています。必要に応じて改変してお使いください。
