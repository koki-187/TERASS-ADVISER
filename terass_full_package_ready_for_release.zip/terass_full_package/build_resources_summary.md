# TERASS業務サポートAI – 構築に必要なファイルとドキュメント

この文書は、デスクトップ版・iOS版アプリの構築に必要となるファイルやドキュメントを整理したものです。適切なフォルダ階層とともに、各ファイルの用途を簡潔にまとめています。

## 🎯 目的

- **デスクトップ版**：Tkinter を用いた Python アプリをビルド・実行するために必要なスクリプトとガイドを整理。
- **iOS版**：Expo/React Native で実装されたモバイルアプリのビルドや設定に必要なファイルを整理。

---

## 📂 デスクトップ版 (terass_desktop_release)

| フォルダ/ファイル | 主な内容・用途 |
|---|---|
| `terass_assistant_with_scenarios.py` | デスクトップアプリのメインスクリプト。Tkinter でチャットUIを構築し、14ステップのシナリオ誘導やナレッジ検索機能を実装します。 |
| `scenario_module.py` | シナリオ誘導の各ステップを定義したモジュール。 |
| `rag_utils.py`, `rag_ingestion.py` | RAG (Retrieval-Augmented Generation) 検索機能に関するユーティリティとデータインジェクションスクリプト。 |
| `assets/` | アプリで使用するアイコンやアバター等を格納。 |
| `bitwarden_guide.md` | Bitwarden Secrets Manager の導入と CLI で安全に秘密情報を注入する方法を解説【124307937905877†L749-L761】。 |
| `packaging_guide.md` | PyInstaller を使って実行ファイル化する手順を解説。`--onefile` オプションで単一実行ファイルを生成する方法が記載されています【882178363917746†L501-L516】。 |
| `README.md` | デスクトップアプリの概要、必要なPythonバージョン、仮想環境の作成、依存ライブラリのインストール手順を説明。 |
| `phase2_docs/` | 今後の開発フェーズに関するドキュメント。現在のビルドには必須ではありません。 |

### デスクトップ版のビルドに必要な手順（概要）

1. Python3環境とpipがインストールされていることを確認。
2. 仮想環境を作成 (`python -m venv venv`) し、アクティブ化。
3. 必要なパッケージをインストール (`pip install openai python-dotenv Pillow`など)。
4. Bitwarden Secrets Manager で APIキー等を管理し、`bws run -- 'python terass_assistant_with_scenarios.py'` のように実行時に注入【124307937905877†L749-L761】。
5. PyInstaller を使って実行ファイルを生成する場合は、`pyinstaller --onefile terass_assistant_with_scenarios.py` を使用【882178363917746†L501-L516】。生成されたファイルと `LICENSE.txt` を同梱して配布します。

---

## 📂 iOS版 (terass_ios_app)

| フォルダ/ファイル | 主な内容・用途 |
|---|---|
| `App.js` | アプリのエントリーポイント。チャット画面とヘルプ・FAQ画面を統合したナビゲーションを設定します。 |
| `app.json` | Expo アプリ設定ファイル。アプリアイコンやバンドルIDなどを定義。 |
| `package.json` | 依存ライブラリとスクリプトを定義。 |
| `assets/` | iOS版で使うアイコン・アバター画像 (`final_icon.png`, `terass_avatar.png` 等)。 |
| `src/ChatScreen.js` | チャット画面を構成し、OpenAI API 連携とシナリオ誘導を実装。 |
| `src/HelpScreen.js` | Bitwarden Secrets Manager の概要と安全な利用方法を示したヘルプ画面。 |
| `src/FAQScreen.js` | よくある質問をまとめたオフライン閲覧用画面。 |
| `src/DevMemoScreen.js` | 実装済み機能や今後の課題を一覧化する開発メモ画面。 |
| `src/scenarios.js` | 「手付金預かり手順」14ステップを定義するモジュール。 |
| `src/openai.js` | OpenAI API との通信関数を定義。 |
| `src/rag.js`, `src/vectorSearch.js` | 簡易検索やベクタ検索APIへの接続処理。 |
| `src/config.js` | APIキーやベクタ検索エンドポイントを設定するファイル。ビルド時に環境変数から注入する仕組みを利用します。 |
| `README.md` | iOSアプリの開発・配布ガイド。Expo CLI のインストール、依存ライブラリの導入 (`npm install`)、環境変数の設定、EAS Buildによる配布手順などを解説。 |

### iOS版のビルドに必要な手順（概要）

1. Node.js と Expo CLI のインストール (`npm install -g expo-cli`)。
2. プロジェクトルートで `npm install` を実行し、依存パッケージを導入。
3. `src/config.js` の APIキーやベクタ検索URLを環境変数または Bitwarden から注入。コードには直接キーを書かない。
4. Expo で開発モード (`expo start`) を実行してシミュレータや Expo Go で動作確認。
5. App Store向けに配布する場合は EAS CLI (`eas build -p ios --profile production`) で .ipa を生成し、TestFlight から配布。

---

## 💡 その他のパッケージ

| パッケージ | 内容・用途 |
|---|---|
| `terass-automation-kit.zip` | Node.js スクリプトと cron 実行例を含む自動化キット。ナレッジデータのスクレイピングやベクタDB更新などを自動化する際に使用します。 |
| `release_package_updated.zip` | `dist/ReleasePackage` フォルダをまとめた配布用アーカイブ。アイコンやライセンスなど配布時に必要なドキュメントのみを含みます。アプリ本体は含まれていないため、ビルドには `terass_desktop_release` と `terass_ios_app` が必要です。 |
| `terass-assistant-app-final.zip` | Webアプリ版 (PWA) の成果物。主にブラウザ向けデモ用であり、デスクトップ・iOSアプリ構築には不要です。 |

## ✅ まとめ

- デスクトップ版のビルドには `terass_desktop_release/terass_desktop_release` 内の Python スクリプト・モジュールとガイド (Bitwarden、パッケージング) が必要。
- iOS 版のビルドには `terass_ios_app` ディレクトリ内のソースコード、`README.md`、`assets/`、`src/` などが必要。
- API キーやパスワードなど機密情報は Bitwarden Secrets Manager で安全に管理し、ビルド・実行時に注入します【124307937905877†L749-L761】。
- 配布用に実行ファイルを作成する場合は PyInstaller を利用し、`--onefile` オプションで単一ファイルを生成します【882178363917746†L501-L516】。iOS 版は EAS CLI で .ipa をビルドします。

