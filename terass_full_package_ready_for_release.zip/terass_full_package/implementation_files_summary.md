# TERASS 業務サポートAI – 実装ファイル整理リスト

以下のリストは、GitHub リポジトリや Google ドライブ、提供された ZIP アーカイブを確認し、実装に必要なファイルとその用途を整理したものです。デスクトップ版と iOS 版のソースコード、オートメーションキット、フェーズ2ドキュメントなどをカテゴリごとにまとめてあります。これを参考に、適切なフォルダ構成でプロジェクトを組み立ててください。

## デスクトップ版アプリ（`terass_desktop_release`）

| ファイル／フォルダ | 主な内容・用途 |
|---|---|
| `terass_assistant_with_scenarios.py` | Tkinter を用いたチャット UI と AI 連携のメインスクリプト。OpenAI API を呼び出し、14 ステップの「手付金預かり」シナリオを誘導します。 |
| `scenario_module.py` | デポジットシナリオなど、会話誘導のステップを定義したモジュール。 |
| `rag_ingestion.py` / `rag_utils.py` | ベクタデータベースへのドキュメント取り込みと検索ユーティリティ。RAG 検索を実装する際に使用します。 |
| `assets/` | アプリのアイコンやアバター画像。`terass_icon.ico` や `terass_avatar.png` が含まれます。GUI で表示されるアイコンはここから参照されます。 |
| `packaging_guide.md` | PyInstaller を用いて Windows/macOS 用の実行ファイルにまとめる手順を説明したガイド【658458228833115†L11-L45】。ライセンスや README を同梱することの重要性も記載されています。 |
| `bitwarden_guide.md` | Bitwarden Secrets Manager の基本と CLI (`bw`/`bws`) の使い方、API キーを安全に注入する方法を解説したガイド【564874123676028†L66-L76】。 |
| `README.md` | プロジェクト概要、依存パッケージインストール方法 (`pip install`)、仮想環境の作成などの基本手順を記載した説明書。 |
| `phase2_docs/` | フェーズ2で実装予定の機能仕様書。`TERASS_ADVISER_SPEC.md` は報酬体系や Agent Class 制度など統合仕様をまとめた文書で、開発計画の理解に役立ちます。`PICKS_INTEGRATION.md` や `LOAN_CHECKER.md` にはピックス統合やローン機能の概要が記されています。 |

### 注意点

- デスクトップ版は Python 3.10 以上が必要です。`requirements.txt` を整備し、必要なライブラリ（`openai`、`python-dotenv`、`Pillow` など）を記載しておきます。  
- 配布用に実行ファイル化する際は `pyinstaller --onefile --name TerassAssistant terass_assistant_with_scenarios.py` を実行し、生成されたバイナリを `LICENSE.txt` と `README.md` と共に ZIP 化します。  
- 秘密情報はコードに書き込まず、Bitwarden Secrets Manager から環境変数として注入します。

## iOS 版アプリ（`terass_ios_app`）

| ファイル／フォルダ | 主な内容・用途 |
|---|---|
| `App.js` | React Native (Expo) アプリのエントリーポイント。チャット画面、FAQ、ヘルプ画面などへのナビゲーションを提供します。 |
| `app.json` | Expo アプリ設定ファイル。アプリ名やバンドル ID、アイコン (`final_icon.png`) を指定します。 |
| `package.json` | React Native の依存ライブラリ定義とスクリプト。`npm install` で必要なパッケージをインストールします。 |
| `assets/` | iOS 版で使うアイコンやアバター。`final_icon.png` はプラットフォーム共通アイコン、`icon_pattern_a/b/c.png` はダッシュボード風の別バリエーションです。 |
| `src/ChatScreen.js` | GiftedChat ライブラリを使ったチャット画面のロジック。OpenAI API への問い合わせやシナリオ誘導を行います。 |
| `src/HelpScreen.js` | Bitwarden の利用方法などを説明するヘルプ画面。 |
| `src/FAQScreen.js` | よくある質問を表示する画面。ユーザーが自己解決できるよう資料を提供します。 |
| `src/DevMemoScreen.js` | 実装済み機能や残課題を記した開発メモ画面。次フェーズのアイデアや優先度確認に活用します。 |
| `src/scenarios.js` | デスクトップ版と同様に「手付金預かり手順」を14ステップで定義したモジュール。 |
| `src/openai.js` | OpenAI ChatCompletion API とのインタフェース。質問メッセージを送り、応答を受け取ります。 |
| `src/rag.js` / `src/vectorSearch.js` | 埋め込み資料の簡易検索と外部ベクタ検索 API 呼び出しを行うユーティリティ。`KNOWLEDGE_API_URL` と `VECTOR_API_URL` は `config.js` で設定します。 |
| `src/config.js` | API キーやエンドポイントの設定ファイル。公開ソースにはプレースホルダが入っており、CI/CD や Bitwarden から安全に値を注入します。 |
| `README.md` | 環境構築からビルド、デプロイまでの詳細な手順を記載したガイド【539003540601541†L47-L63】。Expo CLI のインストール、依存パッケージの導入、iOS ビルド (`eas build -p ios`) の方法などが説明されています。 |

### 注意点

- iOS 版は Expo/React Native 環境を前提としています。Node.js と `expo-cli` をインストールし、`npm install` で依存を揃えます。  
- アイコンやスプラッシュ画像は `assets/final_icon.png` を使用し、`app.json` 内で参照します。  
- OpenAI API キーやベクタ API エンドポイントは直接記述せず、Bitwarden などで管理してください。  
- EAS CLI を用いたビルドでは Apple Developer アカウントが必要です。

## 自動化キット（`terass-automation-kit`）

| ファイル／フォルダ | 主な内容・用途 |
|---|---|
| `.env.example` | 自動化キットで使用する環境変数のテンプレート。実際の値は Bitwarden Secrets Manager で管理し、`.env` にコピーして使用します。 |
| `README.md` | GitHub Actions や Cron で更新収集を自動化する手順を説明するドキュメント。Secrets Manager でのキー登録方法、CI 変数の設定、運用の注意点が記されています。 |
| `src/index.js` | 自動化キットのエントリーポイント。Secrets Manager から取得した情報を用いてスクレイピングやデータ更新を実行します。 |
| `src/scraper.js` | Puppeteer を使って Terass Cloud や Notion から最新情報を収集する雛形スクリプト。必要に応じてセレクタをカスタマイズします。 |
| `src/notify.js` | Slack などへの通知機能の雛形。収集結果をチームに共有する際に利用します。 |
| `scripts/cron.sh` | サーバ上で定期実行するためのサンプルシェルスクリプト。`bws run` を用いて Secrets を注入し、Node.js スクリプトを実行します。 |
| `workflows/ci-deploy.yml` | GitHub Actions 用のテンプレート。リポジトリの Secrets にアクセストークンを設定すれば、定期的なデータ更新が自動で行えます。 |

### 注意点

- `.env` ファイルはリポジトリに含めず、`.env.example` を参考に各自作成してください。  
- Secrets Manager で登録するキーは `OPENAI_API_KEY` や `TERASS_CLOUD_USER` などで、GitHub Actions では `BW_SM_ACCESS_TOKEN` として環境変数に設定します。  
- スクレイピング対象サイトのセレクタが変更された場合は `src/scraper.js` を調整してください。

## 補足パッケージ

| ファイル | 主な内容・用途 |
|---|---|
| `terass_complete_package.zip` | 自動化キット一式とプロジェクト関連のスクリーンショット、簡易ドキュメントがまとめられたアーカイブ。開発補助資料として使用します。 |
| `terass-assistant-app-final.zip` | Web ブラウザ上で動作する簡易チャットアプリ。`index.html`、`script.js`、`style.css` などを含み、参考実装として活用できます。 |
| `TERASS_icon_all_os.zip` | iOS/Android/Windows/macOS 用の公式アイコンセット。`final_icon.png` などが含まれ、アプリのアイコンとして設定します。 |

## 正しく実装するためのチェックリスト

1. **ファイル確認**：上記の表に挙げたファイルが各アーカイブやリポジトリに存在するか確認します。抜け漏れがないかチェックし、不足している場合は再ダウンロード・再取得します。
2. **ライセンスの追加**：配布パッケージには必ず `LICENSE.txt`（MIT ライセンスなど）を含め、README で参照します。ドライブには複数の `LICENSE.md`/`LICENSE.txt` が存在していましたが、最新版を 1 つ選んで同梱してください。  
3. **API キー管理**：`src/config.js` や `.env` ファイルに API キーを直書きしないよう注意し、Bitwarden Secrets Manager を用いて環境変数として注入します。  
4. **ビルド手順の確認**：デスクトップ版では PyInstaller、iOS 版では Expo/EAS の手順に従い、README と `packaging_guide.md` を参照してビルドします。  
5. **UI/UX 最終チェック**：チャット UI やシナリオ誘導、ヘルプ・FAQ・開発メモ画面が正しく表示されるか、テストデバイスで確認します。  
6. **残課題の整理**：開発メモや `phase2_docs` に記載された追加機能（Loan Checker、PICKS 統合など）や改善点を次フェーズで実装できるようタスクとして整理しておきます。

この整理リストを基に、各フォルダの内容を適切に配置すれば、Terass 業務サポートAI アプリのデスクトップ版・iOS 版・自動化キットを問題なく構築・リリースできます。
